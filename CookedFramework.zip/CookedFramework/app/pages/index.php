<?php
pageStart('CookedFramework');

?>

<section class="py-5 border-bottom" children-animation="fade-up" animation-trigger="default" animation-time="0.6s" children-animation-delay="0.14s">
    <div class="container">
      <div class="row align-items-center g-4" >
        <div class="col-12 col-lg-7" children-animation="fade-right" animation-time="0.5s" animation-trigger="default" children-animation-delay="0.14s">
          <img src="<?=fwUrl();?>/public/img/logobig.png" width="95%"/>

          <h1 class="display-5 fw-bold mb-3">
            Prosty framework do budowania aplikacji PHP + JS
          </h1>

          <p class="lead text-muted mb-4">
            CookedFramework stawia na czytelny kod, prosty binding HTML, lekkie API,
            modale z walidacją i wygodną pracę z bazą danych — bez ciężkiego frontendu.
          </p>

          <div class="d-flex flex-wrap gap-3">
            <a href="docs/" class="btn btn-dark btn-lg" animation="pop" animation-delay="0.6s">
              Dokumentacja
            </a>

            <a href="examples/" class="btn btn-outline-secondary btn-lg" animation="pop" animation-delay="0.7s">
              Przykłady
            </a>
          </div>
        </div>

        <div class="col-12 col-lg-5">
          <section class="py-5 border-bottom" children-animation="fade-up" animation-delay="0.5s" animation-trigger="default" animation-time="0.6s" children-animation-delay="0.24s">
            <div class="small text-uppercase text-muted fw-semibold mb-2">
              Główna idea
            </div>

            <div class="vstack gap-3" children-animation="fade-up" animation-delay="0.5s"  animation-trigger="default" animation-time="0.6s" children-animation-delay="0.24s">
              <div class="d-flex align-items-start gap-3">
                <i class="bi bi-check2-circle fs-5 text-success"></i>
                <div>
                  <div class="fw-semibold">Zwykły PHP</div>
                  <div class="text-muted small">Bez nadmiaru warstw i bez rozbudowanego MVC.</div>
                </div>
              </div>

              <div class="d-flex align-items-start gap-3">
                <i class="bi bi-check2-circle fs-5 text-success"></i>
                <div>
                  <div class="fw-semibold">Prosty JS</div>
                  <div class="text-muted small">Krótki kod dla kliknięć, API, bindingu i modali.</div>
                </div>
              </div>

              <div class="d-flex align-items-start gap-3">
                <i class="bi bi-check2-circle fs-5 text-success"></i>
                <div>
                  <div class="fw-semibold">Jasny podział projektu</div>
                  <div class="text-muted small">Framework jako silnik, app jako logika aplikacji, public jako assety.</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>

    <section class="py-5 border-bottom" animation="fade-in" animation-trigger="view" animation-time="0.7s" animation-margin="160px">
    <div class="container">
      <div class="row mb-4" children-animation="fade-up" animation-trigger="view" animation-time="0.55s" children-animation-delay="0.1s" animation-margin="160px">
        <div class="col-12 col-lg-8">
          <div class="small text-uppercase text-muted fw-semibold mb-2">Porównanie</div>
          <h2 class="h3 mb-2">Zredukuj ilość kodu</h2>
          <p class="text-muted mb-0">
            CookedFramework skraca widok i przenosi powtarzalne rzeczy do gotowych helperów.
          </p>
        </div>
      </div>

      <div class="row row-cols-1 row-cols-lg-2 g-4 align-items-start">
        <div class="col d-flex">
          <div class="sticky-top w-100 align-self-start" style="top: 96px;">
            <div class="d-flex align-items-center justify-content-between mb-3">
              <h3 class="h5 mb-0">Bez frameworka</h3>
              <span class="badge text-bg-secondary">Pełny kod</span>
            </div>

            <pre class="bg-dark text-white rounded-4 p-4 mb-0 overflow-auto" animation="reveal-down,typewriter" animation-trigger="view" animation-time="1.5s" animation-delay="0.5,0" animation-margin="140px"><code>&lt;?php
$users = [
  ['name' =&gt; 'Jan'],
  ['name' =&gt; 'Anna']
];
?&gt;
&lt;!doctype html&gt;
&lt;html lang=&quot;pl&quot;&gt;
&lt;head&gt;
  &lt;meta charset=&quot;utf-8&quot;&gt;
  &lt;meta name=&quot;viewport&quot; content=&quot;width=device-width, initial-scale=1&quot;&gt;
  &lt;title&gt;Moja strona&lt;/title&gt;
  &lt;link href=&quot;https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/css/bootstrap.min.css&quot; rel=&quot;stylesheet&quot;&gt;
&lt;/head&gt;
&lt;body&gt;
  &lt;main class=&quot;container py-5&quot;&gt;
    &lt;h1 class=&quot;mb-4&quot;&gt;Moja strona&lt;/h1&gt;

    &lt;div&gt;
      &lt;?php foreach ($users as $user): ?&gt;
        &lt;div&gt;&lt;?= htmlspecialchars($user['name'], ENT_QUOTES, 'UTF-8') ?&gt;&lt;/div&gt;
      &lt;?php endforeach; ?&gt;
    &lt;/div&gt;
  &lt;/main&gt;
&lt;/body&gt;
&lt;/html&gt;</code></pre>
          </div>
        </div>

        <div class="col d-flex">
          <div class="sticky-top w-100 align-self-start" style="top: 96px;">
            <div class="d-flex align-items-center justify-content-between mb-3">
              <h3 class="h5 mb-0">Z frameworkiem</h3>
              <span class="badge text-bg-primary">Równoznaczny efekt</span>
            </div>

            <pre class="bg-dark text-white rounded-4 p-4 mb-0 overflow-auto" animation="reveal-down,typewriter" animation-trigger="view" animation-time="1.5s" animation-delay="0.5,0" animation-margin="140px"><code>&lt;?php
pageStart(&quot;Moja strona&quot;);
?&gt;

&lt;main class=&quot;container py-5&quot;&gt;
  &lt;h1 class=&quot;mb-4&quot;&gt;Moja strona&lt;/h1&gt;

  &lt;div defaultBinding=&quot;users&quot;&gt;
    &lt;div template&gt;{{name}}&lt;/div&gt;
  &lt;/div&gt;
&lt;/main&gt;

&lt;?php
pageEnd([
  'users' =&gt; [
    ['name' =&gt; 'Jan'],
    ['name' =&gt; 'Anna']
  ]
]);
?&gt;</code></pre>
          </div>
        </div>
      </div>
    </div>
  </section>

  <section class="py-5" animation="fade-in" animation-trigger="view" animation-time="1.5s" animation-margin="100px">
    <div class="container">
      <div class="row mb-4">
        <div class="col-12 col-lg-8">
          <h2 class="h3 mb-2">Możliwości frameworka</h2>
          <p class="text-muted mb-0">
            Najczęściej używane rzeczy, które realnie przyspieszają tworzenie aplikacji.
          </p>
        </div>
      </div>

      <div class="list-group" children-animation="fade-right" animation-trigger="view" animation-time="0.55s" children-animation-delay="0.12s" animation-delay="0.08s" animation-margin="280px">
        <div class="list-group-item px-0 py-4 border-bottom ps-4">
          <div class="d-flex align-items-start gap-3">
            <div class="fs-4 text-primary">
              <i class="bi bi-window-stack"></i>
            </div>

            <div class="flex-grow-1">
              <div class="fw-semibold mb-1">Strony PHP bez zbędnej warstwy</div>
              <div class="text-muted">
                Tworzysz zwykłe pliki PHP, a framework zajmuje się renderingiem, layoutem i danymi startowymi.
              </div>
            </div>
          </div>
        </div>

        <div class="list-group-item px-0 py-4 border-bottom ps-4">
          <div class="d-flex align-items-start gap-3">
            <div class="fs-4 text-primary">
              <i class="bi bi-braces"></i>
            </div>

            <div class="flex-grow-1">
              <div class="fw-semibold mb-1">Binding HTML</div>
              <div class="text-muted">
                Masz defaultBinding, binding i innerBinding do prostych i zagnieżdżonych struktur danych.
              </div>
            </div>
          </div>
        </div>

        <div class="list-group-item px-0 py-4 border-bottom ps-4">
          <div class="d-flex align-items-start gap-3">
            <div class="fs-4 text-primary">
              <i class="bi bi-arrow-left-right"></i>
            </div>

            <div class="flex-grow-1">
              <div class="fw-semibold mb-1">Lekkie API</div>
              <div class="text-muted">
                get(), getRaw() i send() pozwalają szybko pobierać lub wysyłać dane bez rozwlekłego fetch().
              </div>
            </div>
          </div>
        </div>

        <div class="list-group-item px-0 py-4 border-bottom ps-4">
          <div class="d-flex align-items-start gap-3">
            <div class="fs-4 text-primary">
              <i class="bi bi-ui-checks-grid"></i>
            </div>

            <div class="flex-grow-1">
              <div class="fw-semibold mb-1">Modale i walidacja</div>
              <div class="text-muted">
                ModalInfo, ModalConfirm i ModalForm z walidacją pól, bez pisania HTML modala ręcznie.
              </div>
            </div>
          </div>
        </div>

        <div class="list-group-item px-0 py-4 border-bottom ps-4">
          <div class="d-flex align-items-start gap-3">
            <div class="fs-4 text-primary">
              <i class="bi bi-database"></i>
            </div>

            <div class="flex-grow-1">
              <div class="fw-semibold mb-1">Praca z bazą</div>
              <div class="text-muted">
                DB_SELECT, DB_INSERT, DB_UPDATE i pozostałe helpery upraszczają najczęstsze operacje.
              </div>
            </div>
          </div>
        </div>

        <div class="list-group-item px-0 py-4 ps-4">
          <div class="d-flex align-items-start gap-3">
            <div class="fs-4 text-primary">
              <i class="bi bi-layout-sidebar-inset"></i>
            </div>

            <div class="flex-grow-1">
              <div class="fw-semibold mb-1">Layouty i komponenty</div>
              <div class="text-muted">
                Masz stały shell, a w aplikacji trzymasz własne strony, layouty i współdzielone komponenty.
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>


<?php
pageEnd([
    'features' => [
        [
            'icon' => 'bi-window-stack',
            'title' => 'Strony PHP bez zbędnej warstwy',
            'text' => 'Tworzysz zwykłe pliki PHP, a framework zajmuje się renderingiem, layoutem i danymi startowymi.'
        ],
        [
            'icon' => 'bi-braces',
            'title' => 'Binding HTML',
            'text' => 'Masz defaultBinding, binding i innerBinding do prostych i zagnieżdżonych struktur danych.'
        ],
        [
            'icon' => 'bi-arrow-left-right',
            'title' => 'Lekkie API',
            'text' => 'get(), getRaw() i send() pozwalają szybko pobierać lub wysyłać dane bez rozwlekłego fetch().'
        ],
        [
            'icon' => 'bi-ui-checks-grid',
            'title' => 'Modale i walidacja',
            'text' => 'ModalInfo, ModalConfirm i ModalForm z walidacją pól, bez pisania HTML modala ręcznie.'
        ],
        [
            'icon' => 'bi-database',
            'title' => 'Praca z bazą',
            'text' => 'DB_SELECT, DB_INSERT, DB_UPDATE i pozostałe helpery upraszczają najczęstsze operacje.'
        ],
        [
            'icon' => 'bi-layout-sidebar-inset',
            'title' => 'Layouty i komponenty',
            'text' => 'Masz stały shell, a w aplikacji trzymasz własne strony, layouty i współdzielone komponenty.'
        ],
    ]
]);
?>
