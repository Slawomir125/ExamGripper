<?php
pageStart('Start');
?>

<h1 class="h3 mb-3">Funkcje frameworka</h1>

<p class="text-muted mb-4" animation="fade-up" animation-trigger="default" animation-time="0.55s" animation-delay="0.08s">
  Każda podstrona pokazuje jedną funkcję w praktycznym użyciu.
</p>

<div class="row g-3"
     defaultBinding="examples"
     children-animation="fade-up"
     animation-trigger="default"
     animation-time="0.5s"
     children-animation-delay="0.07s"
     animation-delay="0.14s">
  <div template class="col-12 col-md-6 col-xl-4">
    <a href="<?= route('functions/{{slug}}') ?>" class="text-decoration-none text-reset d-block h-100">
      <div class="card h-100 shadow rounded-4 overflow-hidden function-tile">
        <div class="card-body p-4">
          <div class="d-flex align-items-start gap-3">
            <div class="function-tile-icon">
              <i class="bi {{icon}}"></i>
            </div>

            <div class="flex-grow-1">
              <div class="fw-bold fs-5 mb-2">{{title}}</div>
              <div class="text-muted small mb-3">{{description}}</div>
              <div class="function-tile-link small fw-semibold">
                Otwórz podgląd
                <i class="bi bi-arrow-right-short ms-1"></i>
              </div>
            </div>
          </div>
        </div>
      </div>
    </a>
  </div>
</div>

<style>
.function-tile-icon {
  width: 3rem;
  height: 3rem;
  flex: 0 0 3rem;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  border-radius: 1rem;
  background: rgba(13, 110, 253, .08);
  color: var(--bs-primary);
  font-size: 1.25rem;
}

.function-tile-link {
  color: var(--bs-primary);
}
</style>

<?php pageEnd([
    'examples' => [
        [
            'slug' => 'binding-js',
            'title' => 'Binding z JavaScript',
            'description' => 'Odświeżanie widoku po wywołaniu Binding.set().',
            'icon' => 'bi-braces-asterisk'
        ],
        [
            'slug' => 'binding-php',
            'title' => 'Binding z PHP',
            'description' => 'Render danych przekazanych bezpośrednio do pageEnd().',
            'icon' => 'bi-filetype-php'
        ],
        [
            'slug' => 'inner',
            'title' => 'Inner binding',
            'description' => 'Listy zagnieżdżone i dostęp do danych nadrzędnych.',
            'icon' => 'bi-diagram-3'
        ],
        [
            'slug' => 'api',
            'title' => 'API / HTTP',
            'description' => 'Pobieranie danych, wysyłanie formularzy i odczyt surowej odpowiedzi.',
            'icon' => 'bi-arrow-left-right'
        ],
        [
            'slug' => 'modal',
            'title' => 'Modale',
            'description' => 'Okna informacyjne, potwierdzenia i formularze uruchamiane z poziomu JS.',
            'icon' => 'bi-window-stack'
        ],
        [
            'slug' => 'db',
            'title' => 'Baza danych',
            'description' => 'Pobieranie rekordów przy użyciu helperów DB.',
            'icon' => 'bi-database'
        ],
        [
            'slug' => 'tabs',
            'title' => 'Tabs',
            'description' => 'Przełączanie sekcji z wykorzystaniem atrybutów HTML.',
            'icon' => 'bi-ui-radios-grid'
        ],
        [
            'slug' => 'drag-and-drop',
            'title' => 'Drag and drop',
            'description' => 'Sortowanie i przenoszenie elementów między listami.',
            'icon' => 'bi-arrows-move'
        ],
        [
            'slug' => 'animations',
            'title' => 'Animacje',
            'description' => 'Efekty uruchamiane po załadowaniu, wejściu w widok lub z JS.',
            'icon' => 'bi-stars'
        ],
    ]
]); ?>
