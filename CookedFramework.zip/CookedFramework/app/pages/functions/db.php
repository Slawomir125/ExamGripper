<?php
pageStart('Data base', 'example-view');
?>

<h1 class="h3 mb-3">Dane z bazy</h1>

<p class="text-muted">
  Widok korzysta z helpera <code>DB_SELECT()</code> i pokazuje rekordy pobrane bezpośrednio z tabeli <code>persons</code>.
</p>

<div class="card">
  <div class="card-body">
    <div defaultBinding="persons">
      <div template class="d-flex justify-content-between align-items-center border-bottom py-2">
        <div>
          <div class="fw-bold">#{{id}} {{name}}</div>
          <div class="text-muted small">{{email}}</div>
        </div>
      </div>
    </div>
  </div>
</div>

<?php pageEnd([
    'persons' => DB_SELECT('persons', ['id', 'name', 'email'], [], 'ORDER BY `id` DESC')
]); ?>
