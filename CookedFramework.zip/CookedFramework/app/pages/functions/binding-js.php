<?php
pageStart('Binding JS', 'example-view');
?>

<div class="d-flex justify-content-between align-items-center mb-3">
  <h1 class="h3 m-0">Binding z JavaScript</h1>
  <button id="btnLoadUsers" class="btn btn-primary">Wczytaj dane</button>
</div>

<p class="text-muted">
  Lista jest uzupełniana dopiero po wywołaniu <code>Binding.set()</code>, dzięki czemu można ją odświeżać po odpowiedzi z API lub po zmianie danych na stronie.
</p>

<div class="card">
  <div class="card-body">
    <div binding="users">
      <div template class="d-flex justify-content-between border-bottom py-2">
        <div>
          <div class="fw-bold">{{name}}</div>
          <div class="text-muted small">{{email}}</div>
        </div>
      </div>
    </div>
  </div>
</div>

<script>
click("btnLoadUsers", () =>
{
    Binding.set("users", [
        { name: "Adam Nowak", email: "adam@test.pl" },
        { name: "Karolina Wójcik", email: "karolina@test.pl" },
        { name: "Marek Zieliński", email: "marek@test.pl" }
    ]);
});
</script>

<?php pageEnd(); ?>
