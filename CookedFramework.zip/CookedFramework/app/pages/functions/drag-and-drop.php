<?php
pageStart('Przykład: drag and drop', 'example-view');
?>

<h1 class="h3 mb-3">Drag and drop</h1>

<p class="text-muted">
  Przykład pokazuje przenoszenie elementów między kolumnami oraz zmianę kolejności wewnątrz jednej listy.
</p>

<div class="row g-4">
  <div class="col-lg-4">
    <div class="card h-100">
      <div class="card-body">
        <h2 class="h5 mb-3">Do przygotowania</h2>

        <div id="todoBoard"
             drop
             drag-group="tasks"
             drop-mode="sort"
             drop-ghost="true"
             drop-ghost-opacity="1"
             class="d-grid gap-2"
             style="min-height: 160px;">

          <div drag drag-value="task-1" class="card border-primary-subtle">
            <div class="card-body d-flex align-items-center gap-3">
              <span drag-handle class="btn btn-sm btn-outline-secondary">↕</span>
              <div>Przygotować odczyty liczników</div>
            </div>
          </div>

          <div drag drag-value="task-2" class="card border-primary-subtle">
            <div class="card-body d-flex align-items-center gap-3">
              <span drag-handle class="btn btn-sm btn-outline-secondary">↕</span>
              <div>Zweryfikować stawki mediów</div>
            </div>
          </div>

          <div drag drag-value="task-3" drag-disabled="true" class="card border-secondary-subtle">
            <div class="card-body d-flex align-items-center gap-3">
              <span class="btn btn-sm btn-outline-secondary disabled">↕</span>
              <div>Archiwalna pozycja</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>

  <div class="col-lg-4">
    <div class="card h-100">
      <div class="card-body">
        <h2 class="h5 mb-3">W realizacji</h2>

        <div id="doingBoard"
             drop
             drag-group="tasks"
             drop-mode="sort"
             drop-ghost="true"
             drop-ghost-opacity="0.35"
             class="d-grid gap-2"
             style="min-height: 160px;">

          <div drag drag-value="task-4" class="card border-warning-subtle">
            <div class="card-body d-flex align-items-center gap-3">
              <span drag-handle class="btn btn-sm btn-outline-secondary">↕</span>
              <div>Przygotować podsumowanie dla klienta</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>

  <div class="col-lg-4">
    <div class="card h-100">
      <div class="card-body">
        <h2 class="h5 mb-3">Zakończone</h2>

        <div id="doneBoard"
             drop
             drag-group="tasks"
             drop-mode="sort"
             drop-ghost="true"
             drop-ghost-opacity="0.35"
             class="d-grid gap-2"
             style="min-height: 160px;">

          <div drag drag-value="task-5" class="card border-success-subtle">
            <div class="card-body d-flex align-items-center gap-3">
              <span drag-handle class="btn btn-sm btn-outline-secondary">↕</span>
              <div>Wysłano rozliczenie za luty</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<div class="row g-4 mt-1">
  <div class="col-lg-4">
    <div class="card">
      <div class="card-body">
        <h2 class="h6 mb-3">Do przygotowania</h2>
        <pre id="todoResult" class="bg-dark text-white rounded p-3 mb-0">[]</pre>
      </div>
    </div>
  </div>

  <div class="col-lg-4">
    <div class="card">
      <div class="card-body">
        <h2 class="h6 mb-3">W realizacji</h2>
        <pre id="doingResult" class="bg-dark text-white rounded p-3 mb-0">[]</pre>
      </div>
    </div>
  </div>

  <div class="col-lg-4">
    <div class="card">
      <div class="card-body">
        <h2 class="h6 mb-3">Zakończone</h2>
        <pre id="doneResult" class="bg-dark text-white rounded p-3 mb-0">[]</pre>
      </div>
    </div>
  </div>
</div>

<script>
const todoDrag = new Drag("todoBoard");
const doingDrag = new Drag("doingBoard");
const doneDrag = new Drag("doneBoard");

const todoResult = document.getElementById("todoResult");
const doingResult = document.getElementById("doingResult");
const doneResult = document.getElementById("doneResult");

function updateBoards()
{
    todoResult.textContent = JSON.stringify(todoDrag.get(), null, 2);
    doingResult.textContent = JSON.stringify(doingDrag.get(), null, 2);
    doneResult.textContent = JSON.stringify(doneDrag.get(), null, 2);
}

todoDrag.onChange = updateBoards;
doingDrag.onChange = updateBoards;
doneDrag.onChange = updateBoards;

updateBoards();
</script>

<?php pageEnd(); ?>
