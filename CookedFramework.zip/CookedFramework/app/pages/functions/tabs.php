<?php
pageStart('Tabs', 'example-view');
?>

<h1 class="h3 mb-3">Tabs</h1>

<p class="text-muted">
  Zakładki porządkują większą ilość treści na jednej stronie i pozwalają przełączać sekcje bez przebudowy całego widoku.
</p>

<div id="docsTabs" tabs>
  <div class="nav nav-tabs mb-3" role="tablist">
    <button class="nav-link active" set-tab="intro">Wprowadzenie</button>
    <button class="nav-link" set-tab="binding">Binding</button>
    <input type="button" class="nav-link" value="API" set-tab="api">
  </div>

  <div class="tab-content">
    <div tab="intro" class="active show">
      Sekcja startowa może zawierać podsumowanie, opis modułu albo najważniejsze informacje na początek.
    </div>

    <div tab="binding">
      W tej zakładce można umieścić konfigurację danych, strukturę list lub opis sposobu renderowania widoku.
    </div>

    <div tab="api">
      To dobre miejsce na adresy endpointów, przykłady odpowiedzi i dodatkowe informacje techniczne.
    </div>
  </div>
</div>

<?php pageEnd(); ?>
