<?php
pageStart('Modal', 'example-view');
?>

<h1 class="h3 mb-3">Modale</h1>

<p class="text-muted">
  Na tej stronie można sprawdzić trzy najczęściej używane warianty: komunikat informacyjny, potwierdzenie akcji i formularz zwracający dane po zapisaniu.
</p>

<div class="d-flex gap-2 mb-3 flex-wrap">
  <button id="btnInfo" class="btn btn-primary">Informacja</button>
  <button id="btnConfirm" class="btn btn-warning">Potwierdzenie</button>
  <button id="btnForm" class="btn btn-success">Formularz</button>
</div>

<pre id="modalResult" class="bg-dark text-white rounded p-3 mb-0"></pre>

<script>
const modalResult = document.getElementById("modalResult");

click("btnInfo", async () =>
{
    await new ModalInfo(
        "Zapis zakończony",
        "Zmiany zostały zapisane poprawnie."
    ).show();

    modalResult.textContent = "Komunikat został zamknięty.";
});

click("btnConfirm", async () =>
{
    const ok = await new ModalConfirm(
        "Usuń wpis",
        "Czy na pewno usunąć wybraną pozycję?"
    ).show();

    modalResult.textContent = "Wynik potwierdzenia: " + ok;
});

click("btnForm", async () =>
{
    const data = await new ModalForm(
        "Nowa osoba",
        [
            Field.text("name", "Imię i nazwisko", "np. Jan Kowalski", [true, "To pole nie może być puste"]),
            Field.email("email", "E-mail", "np. jan@example.com", ["^[^\\s@]+@[^\\s@]+\\.[^\\s@]+$", "Podaj poprawny adres e-mail"])
        ],
        [
            Button.close("Anuluj", false, "btn-secondary"),
            Button.submit("Zapisz", "btn-primary")
        ]
    ).show();

    modalResult.textContent = JSON.stringify(data, null, 2);
});
</script>

<?php pageEnd(); ?>
