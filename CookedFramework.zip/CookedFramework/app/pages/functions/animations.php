<?php
pageStart('Przykład: animate', 'example-view');
?>

<h1 class="h3 mb-3">Animate</h1>

<p class="text-muted">
  Ten przykład pokazuje kilka najczęściej używanych sposobów uruchamiania animacji: od razu po załadowaniu, po wejściu w widok oraz z poziomu JavaScriptu.
</p>

<div class="row g-4 mb-4">
  <div class="col-lg-4">
    <div class="card h-100">
      <div class="card-body">
        <h2 class="h5 mb-3">Start po załadowaniu</h2>

        <div class="border rounded p-4"
             animation="fade-up"
             animation-trigger="default"
             animation-time="0.25s"
             animation-delay="0.7s">
          Sekcja pojawia się od razu po wejściu na stronę.
        </div>
      </div>
    </div>
  </div>

  <div class="col-lg-4">
    <div class="card h-100">
      <div class="card-body">
        <h2 class="h5 mb-3">Wejście w widok</h2>

        <div class="border rounded p-4"
             animation="zoom-in"
             animation-trigger="view"
             animation-time="0.35s"
             animation-margin="100px"
             animation-back="true"
             animation-delay="0.7s">
          Karta uruchamia się po wejściu w obszar widoku i wraca po jego opuszczeniu.
        </div>
      </div>
    </div>
  </div>

  <div class="col-lg-4">
    <div class="card h-100">
      <div class="card-body">
        <h2 class="h5 mb-3">Animacja dzieci</h2>

        <div class="d-grid gap-2"
             children-animation="fade-right"
             animation-trigger="default"
             animation-time="0.25s"
             children-animation-delay="0.1s"
             animation-delay="0.7s">
          <div class="border rounded p-3">Odczyty liczników</div>
          <div class="border rounded p-3">Rozliczenia najemców</div>
          <div class="border rounded p-3">Wiadomości do klientów</div>
        </div>
      </div>
    </div>
  </div>
</div>

<div class="card mb-4">
  <div class="card-body">
    <h2 class="h5 mb-3">Sterowanie z JavaScriptu</h2>

    <div class="d-flex gap-2 mb-3 flex-wrap">
      <button id="btnAnimatePlay" type="button" class="btn btn-primary">Uruchom</button>
      <button id="btnAnimateBack" type="button" class="btn btn-outline-primary">Cofnij</button>
      <button id="btnAnimateReset" type="button" class="btn btn-outline-secondary">Reset</button>
    </div>

    <div id="animateBox"
         class="border rounded p-4"
         animation="fade-left"
         animation-trigger="none"
         animation-time="0.4s"
         animation-back="true">
      Ten element reaguje wyłącznie na metody <code>Animate</code>.
    </div>

    <pre id="animateResult" class="bg-dark text-white rounded p-3 mt-3 mb-0">Gotowe</pre>
  </div>
</div>

<div style="height: 600px;"></div>

<script>
const animateResult = document.getElementById("animateResult");

click("btnAnimatePlay", () =>
{
    Animate.play("animateBox", () =>
    {
        animateResult.textContent = "Animacja została uruchomiona.";
    });
});

click("btnAnimateBack", () =>
{
    Animate.back("animateBox", () =>
    {
        animateResult.textContent = "Animacja wróciła do stanu początkowego.";
    });
});

click("btnAnimateReset", () =>
{
    Animate.reset("animateBox");
    animateResult.textContent = "Stan animacji został zresetowany.";
});
</script>

<?php pageEnd(); ?>
