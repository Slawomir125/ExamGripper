<?php

if (onapi('time')) {
    output([
        'time' => date('H:i:s'),
        'date' => date('Y-m-d')
    ]);
}

if (onapi('echo')) {
    output([
        'received' => input()
    ]);
}

if (onapi('text')) {
    header('Content-Type: text/plain; charset=utf-8');
    echo 'To jest odpowiedź tekstowa zwrócona przez getRaw().';
    exit;
}

pageStart('Api', 'example-view');
?>

<h1 class="h3 mb-3">API / HTTP</h1>

<p class="text-muted">
  Przykład pokazuje trzy podstawowe scenariusze pracy z API: pobranie danych JSON, wysłanie formularza oraz odczyt zwykłego tekstu.
</p>

<div class="d-flex gap-2 mb-3 flex-wrap">
  <button id="btnGet" class="btn btn-primary">get("api::time")</button>
  <button id="btnSend" class="btn btn-success">send("api::echo")</button>
  <button id="btnRaw" class="btn btn-secondary">getRaw("api::text")</button>
</div>

<pre id="result" class="bg-dark text-white rounded p-3 mb-0"></pre>

<script>
const result = document.getElementById("result");

click("btnGet", async () =>
{
    const data = await get("api::time");
    result.textContent = JSON.stringify(data, null, 2);
});

click("btnSend", async () =>
{
    const data = await send("api::echo", {
        name: "Jan Kowalski",
        email: "jan@example.com"
    });

    result.textContent = JSON.stringify(data, null, 2);
});

click("btnRaw", async () =>
{
    result.textContent = await getRaw("api::text");
});
</script>

<?php pageEnd(); ?>
