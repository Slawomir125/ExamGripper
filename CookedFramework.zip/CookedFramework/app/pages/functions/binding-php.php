<?php
pageStart('Binding php', 'example-view');
?>

<h1 class="h3 mb-3">Binding z PHP</h1>

<p class="text-muted">
  Dane przekazane do <code>pageEnd()</code> są od razu dostępne w <code>defaultBinding</code>, dzięki czemu lista pojawia się bez dodatkowego żądania do API.
</p>

<div class="card">
  <div class="card-body">
    <div defaultBinding="users">
      <div template class="d-flex justify-content-between border-bottom py-2">
        <div>
          <div class="fw-bold">{{name}}</div>
          <div class="text-muted small">{{email}}</div>
        </div>
      </div>
    </div>
  </div>
</div>

<?php pageEnd([
    'users' => [
        ['name' => 'Jan Kowalski', 'email' => 'jan@test.pl'],
        ['name' => 'Anna Nowak', 'email' => 'anna@test.pl'],
        ['name' => 'Tomasz Zieliński', 'email' => 'tomek@test.pl'],
    ]
]); ?>
