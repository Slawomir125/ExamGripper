<?php
pageStart('Inner binding', 'example-view');
?>

<h1 class="h3 mb-3">Inner binding</h1>

<p class="text-muted">
  Ten układ przydaje się wszędzie tam, gdzie jeden element zawiera własną listę pozycji, na przykład grupy użytkowników, zamówienia lub sekcje raportu.
</p>

<div defaultBinding="groups">
  <div template class="card mb-3">
    <div class="card-body">
      <h2 class="h5 mb-3">{{name}}</h2>

      <ul class="list-group" innerBinding="{{datas.users}}">
        <li template class="list-group-item">
          <div class="fw-semibold">{{name}}</div>
          <div class="small text-muted">Grupa: {{*.name}}</div>
        </li>
      </ul>
    </div>
  </div>
</div>

<?php pageEnd([
    'groups' => [
        [
            'name' => 'Zespół administracji',
            'datas' => [
                'users' => [
                    ['name' => 'Jan Kowalski'],
                    ['name' => 'Anna Nowak'],
                ]
            ]
        ],
        [
            'name' => 'Zespół rozliczeń',
            'datas' => [
                'users' => [
                    ['name' => 'Piotr Zieliński'],
                    ['name' => 'Ola Wójcik'],
                    ['name' => 'Michał Adamski'],
                ]
            ]
        ]
    ]
]); ?>
