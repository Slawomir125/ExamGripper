<?php

function docsEscape($value): string
{
    return htmlentities((string) $value, ENT_QUOTES, 'UTF-8');
}

function docsBadges(array $items): void
{
    if (empty($items)) {
        return;
    }

    echo '<div class="docs-keywords">';

    foreach ($items as $item) {
        echo '<span class="badge text-bg-light border">' . docsEscape($item) . '</span>';
    }

    echo '</div>';
}

function docsCode(string $code, string $language = 'php'): void
{
    $lang = strtolower(trim($language));
    $langClass = in_array($lang, ['php', 'javascript', 'js', 'html', 'plaintext', 'text'], true) ? $lang : 'plaintext';
    $langLabel = match ($langClass) {
        'php' => 'PHP',
        'javascript', 'js' => 'JavaScript',
        'html' => 'HTML',
        default => ''
    };

    echo '<div class="doc-code doc-code-' . docsEscape($langClass) . '">';

    if ($langLabel !== '') {
        echo '<div class="doc-code-top">';
        echo '<span class="doc-code-badge doc-code-badge-' . docsEscape($langClass) . '">' . docsEscape($langLabel) . '</span>';
        echo '</div>';
    }

    echo '<pre><code class="language-' . docsEscape($langClass) . '">';
    echo htmlentities(trim($code), ENT_QUOTES, 'UTF-8');
    echo '</code></pre>';
    echo '</div>';
}

function docsTable(string $title, array $rows): void
{
    if (empty($rows)) {
        return;
    }

    echo '<div class="doc-subtitle"><i class="bi bi-table me-2"></i>' . docsEscape($title) . '</div>';
    echo '<div class="doc-table-wrap">';
    echo '<div class="table-responsive">';
    echo '<table class="table table-sm doc-params-table align-middle">';
    echo '<thead><tr><th>Nazwa</th><th>Typ</th><th>Opis</th></tr></thead>';
    echo '<tbody>';

    foreach ($rows as $row) {
        echo '<tr>';
        echo '<td><code>' . docsEscape($row['name'] ?? '') . '</code></td>';
        echo '<td>' . docsEscape($row['type'] ?? '') . '</td>';
        echo '<td>' . docsEscape($row['description'] ?? '') . '</td>';
        echo '</tr>';
    }

    echo '</tbody>';
    echo '</table>';
    echo '</div>';
    echo '</div>';
}

function docsHero(
    string $title,
    string $description,
    ?string $example = null,
    string $language = 'php',
    array $badges = [],
    array $notes = []
): void {
    echo '<div class="doc-intro">';
    echo '<div class="doc-intro-header">';
    echo '<div class="doc-intro-kicker"><i class="bi bi-info-circle"></i>Wprowadzenie</div>';
    echo '<h2 class="doc-intro-title">' . docsEscape($title) . '</h2>';
    echo '<p class="doc-intro-text">' . docsEscape($description) . '</p>';
    echo '</div>';

    docsBadges($badges);

    if ($example !== null && trim($example) !== '') {
        echo '<div class="doc-intro-example-title"><i class="bi bi-code-square me-2"></i>Przykład</div>';
        docsCode($example, $language);
    }

    if (!empty($notes)) {
        echo '<div class="doc-note-stack">';
        foreach ($notes as $note) {
            echo '<div class="doc-note-box">' . docsEscape($note) . '</div>';
        }
        echo '</div>';
    }

    echo '</div>';
}

function docsFunctionCard(
    string $kind,
    string $title,
    string $signature,
    string $description,
    array $params = [],
    string $returns = '',
    array $examples = [],
    string $language = 'php',
    array $notes = []
): void {
    $kindClass = strtolower(str_replace([' ', '(', ')'], ['-', '', ''], $kind));
    $langClass = strtolower($language);

    echo '<article class="doc-card doc-kind-' . docsEscape($kindClass) . ' doc-lang-' . docsEscape($langClass) . '">';
    echo '<div class="doc-card-top">';
    echo '<span class="doc-kind-pill">' . docsEscape($kind) . '</span>';
    echo '</div>';
    echo '<h3 class="doc-card-title">' . docsEscape($title) . '</h3>';
    echo '<div class="doc-signatures">';
    echo '<div class="doc-signature">' . docsEscape($signature) . '</div>';
    echo '</div>';
    echo '<p class="doc-card-text">' . docsEscape($description) . '</p>';

    docsTable('Parametry', $params);

    if ($returns !== '') {
        echo '<div class="doc-returns"><strong>Zwraca:</strong> ' . docsEscape($returns) . '</div>';
    }

    if (!empty($notes)) {
        echo '<div class="doc-subtitle"><i class="bi bi-bookmark-star me-2"></i>Uwagi</div>';
        foreach ($notes as $note) {
            echo '<div class="doc-note-box">' . docsEscape($note) . '</div>';
        }
    }

    if (!empty($examples)) {
        echo '<div class="doc-subtitle"><i class="bi bi-code-square me-2"></i>Przykład</div>';
        foreach ($examples as $example) {
            docsCode($example, $language);
        }
    }

    echo '</article>';
}

function docsInfoCards(array $items): void
{
    if (empty($items)) {
        return;
    }

    echo '<div class="doc-grid">';

    foreach ($items as $item) {
        echo '<article class="doc-card doc-kind-framework doc-lang-plaintext">';
        echo '<h3 class="doc-card-title">' . docsEscape($item['title'] ?? '') . '</h3>';
        echo '<p class="doc-card-text">' . docsEscape($item['text'] ?? '') . '</p>';

        if (!empty($item['list'])) {
            echo '<ul class="doc-list mb-0">';
            foreach ($item['list'] as $listItem) {
                echo '<li>' . docsEscape($listItem) . '</li>';
            }
            echo '</ul>';
        }

        echo '</article>';
    }

    echo '</div>';
}

$docsCategoryGroups = [
    [
        'title' => 'Podstawowe',
        'items' => [
            ['id' => 'intro', 'label' => 'Wprowadzenie'],
            ['id' => 'structure', 'label' => 'Struktura projektu'],
            ['id' => 'routing', 'label' => 'Routing'],
            ['id' => 'create-pages', 'label' => 'Tworzenie stron'],
            ['id' => 'config', 'label' => 'Config'],
        ],
    ],
    [
        'title' => 'Funkcje',
        'items' => [
            ['id' => 'binding', 'label' => 'Binding'],
            ['id' => 'events', 'label' => 'Eventy'],
            ['id' => 'http-api', 'label' => 'Http i API'],
            ['id' => 'modals', 'label' => 'Modale'],
            ['id' => 'tabs', 'label' => 'Zakładki'],
            ['id' => 'db', 'label' => 'Baza Danych'],
            ['id' => 'layouts', 'label' => 'Layouty'],
            ['id' => 'components', 'label' => 'Componenty'],
            ['id' => 'animations', 'label' => 'Animacje'],
        ],
    ],
    [
        'title' => 'Inne',
        'items' => [
            ['id' => 'ai-docs', 'label' => 'Dokumentacja dla AI'],
            ['id' => 'ai', 'label' => 'AI'],
            ['id' => 'workflow', 'label' => 'workflow'],
        ],
    ],
];

$aiPromptOldA = <<<'TEXT'
CookedFramework. Projekt oparty o PHP + JavaScript + HTML + Bootstrap. Główny routing przez index.php. Strony tworzyć jako zwykłe pliki PHP w app/pages/. Każda nowa strona ma najczęściej schemat: pageStart(title, template, templateData) -> zwykły HTML/PHP -> pageEnd(pageData). pageStart wybiera layout body. pageEnd przekazuje dane do frontendu. Layouty są w app/layouts/ i służą do układu body. W layoucie <?= $content ?> oznacza zawartość strony. Componenty są w app/components/ i służą do współdzielonych fragmentów HTML jak menu/sidebar/footer. Nie używać componentów JS do renderowania prostych danych. Do renderowania danych w HTML preferować binding. defaultBinding = dane automatyczne z pageEnd(). binding = ręczne Binding.set(). innerBinding = listy zagnieżdżone. template = element wzorcowy do klonowania. Placeholdery obsługują pola bieżącego obiektu, indeks i parenty. Jeśli da się użyć bindingu, nie budować własnego renderera list w JS. app/config.php trzyma title, default_template, db, menu_items. Czytać config przez fwConfig(). URL budować przez fwUrl(). Bazowy adres przez fwBaseUrl(). Aktualna ścieżka przez fwCurrentPath(). Obrazy i grafiki trzymać w public/img. Skrypty i style w public/assets. Wspólne helpery selektorów z app.js: normalizeSelector, getElement, getElements. Eventy JS: click, clicked, clickData, change, changeData, getPageData. HTTP JS: send(url,data) POST JSON, get(url,params) GET JSON data, getRaw(url,params) GET text. API PHP: input(), fileInput(), output(array), error(code,message), onapi(name). Jeśli tworzysz funkcjonalność API, pokazuj pełny kontekst: osobny kod PHP po stronie serwera oraz osobny kod JS po stronie strony. Baza danych: DB_QUERY, DB_GET, DB_EXECUTE, DB_LAST_ID, DB_TABLE, DB_SELECT, DB_INSERT, DB_UPDATE. Dla funkcji z parametrami opcjonalnymi używać jednej sygnatury z parametrami opcjonalnymi, nie wypisywać wielu wersji tej samej funkcji. Modale: Modal.show(modal) albo modal.show(). Typy modali: ModalInfo, ModalConfirm, ModalForm. Pola i przyciski przez Field, Button, ModalField, ModalButton. Tabs: HTML przez tabs + set-tab + tab, JS przez new Tabs(container) i metody set/get/getIndex/next/prev. Animacje: HTML przez animation, children-animation, animation-trigger, animation-time, animation-delay, animation-back, animation-once, animation-margin, children-animation-delay. JS przez Animate.play/back/reset. Layouty: tworzyć pliki PHP w app/layouts/, używać <?= $content ?> jako miejsca na zawartość strony, wybierać layout przez drugi argument pageStart(). Componenty: tworzyć pliki PHP w app/components/, używać component(name, data). Jeśli użytkownik prosi o jedną stronę, generować kompletną stronę gotową do wklejenia do app/pages/, razem z odpowiednim pageStart/pageEnd, poprawnym layoutem i użyciem frameworka zgodnym z istniejącym kodem z zipa. Nie mieszać wzorców spoza frameworka. Nie zastępować bindingu componentami. Nie budować zbędnych abstrakcji. Przykłady mają być praktyczne, pełne, z pełnym kontekstem wdrożenia i gotowe do użycia.
TEXT;

$aiPromptOldB = <<<'TEXT'
Pracujesz na własnym frameworku PHP + JS o nazwie CookedFramework.
Masz generować kod zgodny z istniejącym frameworkiem i jego API, a nie tworzyć nową architekturę.

Dołączony ZIP projektu jest źródłem prawdy dla szczegółów działania funkcji, helperów, layoutów i plików frameworka.
Ta wiadomość opisuje sposób pracy, strukturę projektu i zasady generowania kodu.
Osobna wiadomość zawiera listę funkcji i mechanizmów, które możesz wykorzystać.

Główna filozofia

CookedFramework jest:

lekki,
prosty,
oparty o zwykły PHP, HTML, CSS i JavaScript,
oparty o Bootstrap do layoutu i wyglądu,
bez React, Vue, Alpine, jQuery i innych obcych frameworków.

Najważniejsze zasady:

najpierw używaj mechanizmów frameworka, dopiero potem ręcznego kodu,
jeśli coś da się zrobić helperem albo atrybutem HTML, użyj tego,
nie twórz nadmiarowych warstw, wrapperów, MVC i abstrakcji,
kod ma być prosty, czytelny i praktyczny,
Bootstrap służy do układu i wyglądu, nie do zastępowania logiki frameworka,
jeśli użytkownik prosi o poprawki do istniejącego kodu, rób minimalne zmiany,
nie zmieniaj nazw funkcji i zmiennych bez potrzeby,
jeśli zmiany obejmują więcej niż 2 funkcje w pliku, zwracaj cały plik,
domyślnie zapisuj całość danych jednym wspólnym zapisem, chyba że użytkownik wyraźnie poprosi inaczej,
teksty na stronie mają być pisane dla użytkownika końcowego, nie mogą zawierać meta-komentarzy wynikających z implementacji.
Jak budować strony

Strony są zwykłymi plikami PHP w:

app/pages/

Typowy schemat strony:

pageStart(...)
HTML / PHP / JS
pageEnd(...)

Zasady:

nie buduj własnego MVC,
nie twórz dodatkowego routingu,
nie twórz własnych rendererów danych, jeśli framework już ma binding,
strona ma być gotowym plikiem PHP do wklejenia do app/pages/.
Routing

Routing przechodzi przez główny index.php.

Adres URL jest mapowany na plik strony w app/pages/.
Framework obsługuje wejście na strony bez budowania osobnych kontrolerów.
Jeśli tworzysz linki w HTML, używaj helpera route(...), żeby adres był budowany poprawnie i bezpiecznie.

Layouty i komponenty
Layouty
są w app/layouts/
odpowiadają za układ <body>
<?= $content ?> oznacza miejsce na zawartość strony
layout wybierasz przez pageStart(...)
Componenty
są w app/components/
służą do współdzielonych fragmentów widoku
używaj ich do menu, sekcji powtarzalnych, wspólnego UI
nie używaj componentów do renderowania prostych danych, jeśli lepszy jest binding
Aktualna struktura projektu
Publiczne pliki
public/ — pliki dostępne z przeglądarki
public/assets/ — wspólne skrypty i style
public/img/ — obrazy i grafiki
Pliki aplikacji
app/pages/ — strony
app/layouts/ — layouty
app/components/ — komponenty
app/db/ — pliki SQL opisujące strukturę bazy
app/config.php — konfiguracja projektu
Framework
framework/ — kod frameworka
Dane techniczne frameworka
datas/ — dane robocze frameworka, niedostępne po URL
datas/logs/ — logi błędów
datas/logs/php.log — logi błędów PHP
datas/logs/sql.log — logi błędów SQL
datas/dbScheme/ — dane techniczne związane ze stanem synchronizacji schematu
datas/dbScheme/state.log — stan wykonanych lub zaktualizowanych plików SQL

Ważna zasada:

app/ zawiera content i definicje użytkownika,
datas/ zawiera dane techniczne generowane przez framework.
Binding — podstawowy sposób renderowania danych

Binding jest jednym z najważniejszych mechanizmów frameworka i powinien być domyślnym sposobem wyświetlania danych.

Najważniejsze elementy:

defaultBinding
binding
innerBinding
template
Binding.set(...)

Zasady:

jeśli dane pochodzą z PHP przy ładowaniu strony, preferuj defaultBinding,
jeśli dane są ustawiane lub odświeżane z JS, używaj Binding.set(...),
binding stosuj nie tylko do list, ale też do pojedynczych elementów i bloków,
jeśli renderujesz listę, używaj template,
template stosuj tylko przy listach,
jeśli dane są zagnieżdżone, używaj innerBinding,
nie używaj ręcznego innerHTML, jeśli można użyć bindingu,
nie buduj własnego renderera list w JS, jeśli da się to zrobić bindingiem.

Ważne:

elementy renderowane bindingiem mogą nie istnieć od razu w DOM,
nie inicjalizuj logiki zależnej od tych elementów zbyt wcześnie,
nie mieszaj wielu niezależnych mechanizmów renderowania tych samych elementów,
Binding.init() jest wywoływane tylko w app.js i nie wolno wywoływać go ponownie w kodzie stron.
HTTP / API

Do komunikacji z backendem używaj helperów frameworka.

Zasady:

jeśli pokazujesz API, dawaj pełen kontekst:
kod PHP po stronie strony / endpointu
kod JS, który wywołuje API
nie pokazuj urwanych fragmentów bez kontekstu,
jeśli formularz zapisuje dane, domyślnie projektuj jeden wspólny zapis.
Baza danych i schema sync

Framework ma mechanizm synchronizacji schematu bazy.

Źródłowe pliki SQL są w:

app/db/

Przy pierwszym użyciu DB w requestcie framework:

sprawdza pliki SQL w app/db/,
porównuje ich stan z datas/dbScheme/state.log,
wykonuje nowe lub zmienione pliki,
zapisuje stan synchronizacji w datas/dbScheme/state.log.

Założenia:

framework może utworzyć brakującą tabelę,
jeśli definicja tabeli została rozszerzona, może dodać brakujące kolumny,
nie należy zakładać automatycznego usuwania kolumn,
nie należy zakładać automatycznej zmiany typów istniejących kolumn,
to nie jest pełny system migracji wersjonowanych.
Logi błędów
PHP

Logi błędów PHP trafiają do:

datas/logs/php.log
SQL

Logi błędów SQL trafiają do:

datas/logs/sql.log

Logi są agregowane i zawierają historię wystąpień.
Jeśli debug = true, błędy mają być widoczne normalnie.
Jeśli save_errors = true, błędy mają być zapisywane do logów także w trybie debug.
Jeśli save_errors = false, framework nie zapisuje błędów do logów.

Modale

Jeśli framework ma własne modale, używaj ich.
Nie twórz ręcznie HTML modala, jeśli istnieje helper frameworka.

Zasady:

pokazuj realne użycie modali,
jeśli modal zbiera dane, używaj ModalForm,
jeśli modal potwierdza akcję, używaj ModalConfirm,
jeśli modal tylko informuje, używaj ModalInfo,
przy edycji danych podstawiaj wartości bezpośrednio do pól formularza, a nie opisuj starych danych nad formularzem.
Tabs

Tabs mają korzystać z mechanizmu frameworka, a nie z ręcznego przełączania, jeśli nie jest to potrzebne.

Zasady:

podstawowa logika ma być prosta i czytelna,
jeśli nie trzeba używać klas Bootstrapa do sterowania widocznością, używaj normalnego display,
set-tab może działać dla button i input type="button".
Drag and drop

Mechanizm drag-and-drop ma być oparty o istniejące API frameworka.

Zasady:

nie używaj drag-item-id, tylko drag-value,
jeśli nie ma drag-handle, przeciąga się cały element,
obiekt Drag ma mieć onChange,
przykłady mają być praktyczne,
binding jest dobrym sposobem ładowania kafelków do drag-and-drop,
przy dynamicznych strukturach najpierw renderuj dane, potem inicjalizuj Drag.
Animacje

Framework ma system animacji oparty o atrybuty HTML i sterowanie z JS.

Zasady:

sterowanie ma opierać się na atrybutach, nie na własnym systemie klas,
animacja ma od razu przechodzić do poprawnego stanu początkowego,
nie może migać ani restartować się bez potrzeby,
children-animation nie może nadpisywać dzieci, które mają własne animacje,
typewriter ma pisać znak po znaku,
reveal-down ma kończyć się normalnym stanem bez artefaktów.
Styl kodu JS
Zwykłe funkcje

Jeśli funkcja nie jest callbackiem, zapisuj ją jako:

function sendForm()
{

}

Nie używaj dla zwykłych funkcji stylu:

const sendForm = () => {}
const sendForm = async () => {}
Callbacki

Jeśli funkcja jest przekazywana jako parametr, zapisuj ją strzałkowo, np.:

click("save-button", () => { ... })
onReady

Jeśli kod jest na dole strony albo nie trzeba czekać na DOM, nie owijaj wszystkiego bez potrzeby w onReady(...).
onReady(...) stosuj tylko tam, gdzie naprawdę jest potrzebne.

Styl HTML
małe elementy typu button, a, input mogą być w jednej linii,
jeśli rozbijasz atrybuty na wiele linii, znak > ma być na końcu ostatniej linii z atrybutem, a nie w osobnej linii.
Styl tekstów na stronie

Pisz jak wersję produkcyjną.

Nie używaj sformułowań typu:

„to jest pierwsza wersja”
„tu binding jest ustawiany ręcznie”
„ten przykład pokazuje”
„dodaj element na dole formularza”

Zamiast tego:

pisz naturalnie,
krótko,
z perspektywy użytkownika końcowego,
bez meta-komentarzy o implementacji.
Najważniejsze rzeczy do zapamiętania
najpierw używaj mechanizmów frameworka, dopiero potem ręcznego kodu,
binding jest podstawowym sposobem renderowania danych,
template stosuj tylko przy listach,
nie mieszaj wielu mechanizmów renderowania tych samych elementów,
uważaj na timing DOM przy elementach generowanych bindingiem,
Binding.init() tylko w app.js,
domyślnie zapisuj wszystkie dane razem jednym zapisem,
menu ma być możliwie niezależne od danych przekazywanych przez pageStart(...),
używaj helperów frameworka zamiast ręcznego boilerplate,
Bootstrap ma pomagać w układzie, nie zastępować logiki frameworka,
jeśli użytkownik chce pełny plik, daj pełny plik,
jeśli zmiany są większe niż drobna poprawka, zwracaj cały skrypt.
Jak masz generować kod

Masz generować kod:

zgodnie z istniejącym frameworkiem,
bez zmiany jego filozofii,
bez obcych bibliotek,
z wykorzystaniem pageStart/pageEnd, bindingu, atrybutów i helperów,
z naciskiem na prostotę, spójność i praktyczne użycie istniejącego API.

Jeśli użytkownik prosi o jedną stronę:

wygeneruj kompletny plik PHP gotowy do wklejenia do app/pages/

Jeśli użytkownik prosi o poprawki:

rób minimalne zmiany
przy większych zmianach zwracaj cały plik

Jeśli coś da się zrobić bindingiem:

nie buduj ręcznego renderera

Jeśli jest helper frameworka:

użyj helpera, nie twórz obejścia

Jeśli nie masz pewności co do szczegółu działania:

sprawdź ZIP projektu, bo to on jest źródłem prawdy dla implementacji.
TEXT;

$aiFunctionsText = <<<'TEXT'
PHP / framework
pageStart — rozpoczyna stronę i wybiera layout
pageEnd — kończy stronę i przekazuje dane do frontendu
component — renderuje współdzielony fragment widoku
fwConfig — odczytuje konfigurację frameworka
fwUrl — buduje adres URL
fwBaseUrl — zwraca bazowy adres aplikacji
fwCurrentPath — zwraca aktualną ścieżkę strony
route — buduje bezpieczny URL do użycia w HTML
input — pobiera dane wejściowe requestu
fileInput — pobiera dane wejściowe z obsługą plików
output — zwraca odpowiedź JSON
error — zwraca błąd API
onapi — sprawdza aktualną akcję API
Baza danych
DB_QUERY — wykonuje zapytanie i zwraca listę rekordów
DB_GET — pobiera pojedynczy rekord
DB_EXECUTE — wykonuje zapytanie modyfikujące dane
DB_LAST_ID — zwraca ostatnie ID po insercie
DB_TABLE — pobiera całą tabelę
DB_SELECT — buduje prosty select
DB_INSERT — wstawia rekord
DB_UPDATE — aktualizuje rekord
schema sync — uruchamia pliki SQL z app/db/ i zapisuje stan w datas/dbScheme/state.log
logi SQL — zapisują historię błędów do datas/logs/sql.log
Binding
defaultBinding — automatyczne dane z pageEnd
binding — ręczne wiązanie danych
innerBinding — wiązanie danych zagnieżdżonych
template — wzorzec elementu dla list
Binding.set — ustawia dane z JS
JS — podstawowe helpery
normalizeSelector — normalizuje selektor
getElement — zwraca pojedynczy element
getElements — zwraca listę elementów
getPageData — zwraca dane strony z backendu
setText — ustawia tekst elementu
hide — ukrywa lub pokazuje element
getValue — pobiera wartość z pola
hasItems — sprawdza, czy tablica ma elementy
onReady — uruchamia kod po gotowości DOM, jeśli to potrzebne
JS — eventy
click — obsługuje kliknięcia delegacyjnie
clicked — alias dla click
clickData — obsługuje kliknięcia po atrybucie
change — obsługuje zmianę pola
changeData — obsługuje zmianę po atrybucie
edit — reaguje na bieżącą edycję pola
editData — reaguje na edycję po atrybucie
keyDown — obsługuje keydown
keyUp — obsługuje keyup
keyDownData — obsługuje keydown po atrybucie
keyUpData — obsługuje keyup po atrybucie
JS — HTTP
send — wysyła dane POST do backendu
get — pobiera JSON z backendu
getRaw — pobiera surowy tekst
Modale
Modal.show — pokazuje modal
ModalInfo — modal informacyjny
ModalConfirm — modal potwierdzenia
ModalForm — modal formularza
Field — definicje pól modala
Button — definicje przycisków modala
ModalField — pojedyncze pole modala
ModalButton — pojedynczy przycisk modala
Tabs
Tabs — obsługuje zakładki
set-tab — wskazuje zakładkę do przełączenia
tab — oznacza panel zakładki
set — ustawia aktywną zakładkę
get — zwraca aktywną zakładkę
getIndex — zwraca indeks aktywnej zakładki
next — przechodzi do kolejnej zakładki
prev — przechodzi do poprzedniej zakładki
Drag and drop
drag — oznacza element przeciągany
drop — oznacza kontener docelowy
drag-value — przechowuje wartość elementu
drag-disabled — wyłącza przeciąganie
drag-handle — ustawia uchwyt przeciągania
drop-ghost — pokazuje miejsce upuszczenia
drop-ghost-opacity — steruje przezroczystością ghosta
Drag — steruje logiką drag and drop
Animacje
animation — ustawia preset animacji
children-animation — animuje dzieci elementu
animation-trigger — ustawia trigger animacji
animation-margin — ustawia margines triggera view
animation-back — pozwala cofać animację
animation-once — uruchamia animację tylko raz
animation-time — ustawia czas animacji
animation-delay — ustawia opóźnienie animacji
children-animation-delay — ustawia opóźnienie między dziećmi
animation-easing — ustawia easing
Animate.play — uruchamia animację z JS
Animate.back — cofa animację z JS
Animate.reset — resetuje animację z JS
TEXT;

pageStart('Dokumentacja', 'docs', [
    'activeMenu' => 'docs',
    'bodyClass' => 'bg-body-tertiary',
    'sidebarTitle' => 'CookedFramework',
    'sidebarGroups' => $docsCategoryGroups,
]);
?>

<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.13.1/font/bootstrap-icons.css">

<style>
.docs-layout {
  min-width: 0;
}

.docs-content {
  min-width: 0;
}

.docs-sidebar-stick {
  position: sticky;
  top: 1rem;
  height: calc(100vh - 2rem);
}

.docs-sidebar {
  height: 100%;
  overflow: auto;
}

.docs-nav-group + .docs-nav-group {
  margin-top: 1rem;
}

.docs-nav-group-button {
  display: none;
}

.docs-nav-group-title {
  font-size: .78rem;
  font-weight: 900;
  letter-spacing: .08em;
  text-transform: uppercase;
  color: var(--bs-secondary-color);
  margin-bottom: .55rem;
  padding-left: .2rem;
}

.docs-nav-group-body {
  padding-top: 0;
}

.docs-nav-link {
  display: block;
  padding: .72rem .95rem;
  border-radius: .9rem;
  color: var(--bs-emphasis-color);
  text-decoration: none;
  font-size: 1rem;
  font-weight: 500;
  line-height: 1.25;
  letter-spacing: -.01em;
}

.docs-nav-link:hover,
.docs-nav-link.active {
  background: var(--bs-tertiary-bg);
  color: var(--bs-primary);
}

.docs-nav-link.active {
  font-weight: 800;
}

.docs-search-empty {
  display: none;
}

.doc-section {
  display: none;
  scroll-margin-top: 5rem;
  margin-bottom: 3rem;
}

.doc-section.is-active {
  display: block;
}

.doc-section-header {
  margin-bottom: 1.5rem;
  padding-bottom: 1rem;
  border-bottom: 1px solid var(--bs-border-color);
}

.doc-section-header p {
  margin-bottom: 0;
  color: var(--bs-secondary-color);
  line-height: 1.75;
}

.doc-section-title-strong {
  font-size: clamp(1.7rem, 2vw, 2.2rem);
  font-weight: 900;
  letter-spacing: -.03em;
  margin-bottom: .35rem;
}

.doc-intro {
  background: linear-gradient(180deg, rgba(13,110,253,.06), rgba(13,110,253,0));
  border: 1px solid var(--bs-border-color);
  border-radius: 1.5rem;
  padding: 2rem;
  margin-bottom: 2rem;
}

.doc-intro-kicker {
  display: inline-flex;
  align-items: center;
  gap: .45rem;
  font-size: .8rem;
  font-weight: 900;
  letter-spacing: .08em;
  text-transform: uppercase;
  color: var(--bs-primary);
  margin-bottom: .5rem;
}

.doc-intro-title {
  font-size: clamp(1.7rem, 2.2vw, 2.4rem);
  font-weight: 900;
  letter-spacing: -.03em;
  margin-bottom: .75rem;
}

.doc-intro-text {
  font-size: 1.03rem;
  line-height: 1.8;
  color: var(--bs-secondary-color);
  margin-bottom: 0;
}

.doc-intro-example-title {
  display: inline-flex;
  align-items: center;
  font-size: 1rem;
  font-weight: 800;
  letter-spacing: -.01em;
  color: var(--bs-emphasis-color);
  margin: 1.4rem 0 .85rem 0;
}

.docs-keywords {
  display: flex;
  flex-wrap: wrap;
  gap: .5rem;
  margin-top: 1rem;
}

.docs-keywords .badge {
  font-weight: 600;
}

.doc-subtitle {
  display: flex;
  align-items: center;
  font-size: 1.22rem;
  font-weight: 900;
  letter-spacing: -.02em;
  color: var(--bs-emphasis-color);
  margin: 2rem 0 1rem 0;
  padding: .8rem 0 0 0;
  border-top: 3px solid var(--bs-border-color);
}

.doc-grid {
  display: grid;
  grid-template-columns: 1fr;
  gap: 1rem;
}

.doc-card {
  background: #fff;
  border: 1px solid var(--bs-border-color);
  border-radius: 1rem;
  padding: 1.35rem;
  box-shadow: 0 .25rem 1rem rgba(0,0,0,.04);
}

.doc-kind-funkcja-php,
.doc-kind-funkcja-js,
.doc-kind-konstruktor {
  border-top: 4px solid var(--bs-primary);
}

.doc-kind-obiekt,
.doc-kind-dokumentacja-dla-ai {
  border-top: 4px solid #6f42c1;
}

.doc-kind-framework,
.doc-kind-html,
.doc-kind-struktura {
  border-top: 4px solid #198754;
}

.doc-card-top {
  display: flex;
  align-items: center;
  justify-content: flex-start;
  margin-bottom: .85rem;
}

.doc-kind-pill {
  display: inline-flex;
  align-items: center;
  padding: .34rem .72rem;
  border-radius: 999px;
  font-size: .78rem;
  font-weight: 900;
  letter-spacing: .04em;
  text-transform: uppercase;
  background: var(--bs-tertiary-bg);
  color: var(--bs-emphasis-color);
}

.doc-lang-javascript .doc-kind-pill,
.doc-lang-js .doc-kind-pill {
  background: rgba(255, 193, 7, .16);
  color: #8a6d00;
}

.doc-lang-php .doc-kind-pill {
  background: rgba(13, 110, 253, .12);
  color: #0d6efd;
}

.doc-card-title {
  font-size: 1.22rem;
  font-weight: 800;
  letter-spacing: -.02em;
  margin-bottom: .8rem;
}

.doc-card-text {
  color: var(--bs-secondary-color);
  line-height: 1.78;
}

.doc-signatures {
  display: flex;
  flex-direction: column;
  gap: .5rem;
  margin-bottom: 1rem;
}

.doc-signature {
  display: inline-block;
  width: fit-content;
  max-width: 100%;
  overflow: auto;
  font-family: var(--bs-font-monospace);
  font-size: .95rem;
  line-height: 1.45;
  background: var(--bs-tertiary-bg);
  border: 1px solid var(--bs-border-color);
  border-radius: .85rem;
  padding: .55rem .8rem;
}

.doc-returns {
  margin-top: 1rem;
  padding-top: .9rem;
  border-top: 1px dashed var(--bs-border-color);
  color: var(--bs-secondary-color);
  line-height: 1.7;
}

.doc-table-wrap {
  margin: 1rem 0 1.35rem 0;
  padding: .35rem;
  border: 1px solid var(--bs-border-color);
  border-radius: 1rem;
  background: #fff;
}

.doc-params-table {
  margin-bottom: 0;
}

.doc-params-table td,
.doc-params-table th {
  vertical-align: top;
  white-space: normal;
}

.doc-note-stack {
  display: grid;
  gap: .85rem;
  margin-top: 1rem;
}

.doc-note-box {
  background: var(--bs-light);
  border-left: 4px solid var(--bs-primary);
  border-radius: .75rem;
  padding: 1rem;
  line-height: 1.7;
}

.doc-code {
  margin: 0 0 .85rem 0;
  border-radius: 1rem;
  overflow: hidden;
  border: 2px solid #30363d;
  background: #1f2328;
}

.doc-code:last-child {
  margin-bottom: 0;
}

.doc-code-top {
  display: flex;
  align-items: center;
  justify-content: flex-start;
  padding: .6rem .8rem 0 .8rem;
  background: #1f2328;
}

.doc-code-badge {
  display: inline-flex;
  align-items: center;
  border-radius: 999px;
  padding: .28rem .65rem;
  font-size: .72rem;
  font-weight: 900;
  letter-spacing: .04em;
  text-transform: uppercase;
}

.doc-code-badge-php {
  background: rgba(13, 110, 253, .18);
  color: #7cb8ff;
}

.doc-code-badge-javascript,
.doc-code-badge-js {
  background: rgba(255, 193, 7, .18);
  color: #ffd54d;
}

.doc-code-badge-html {
  background: rgba(25, 135, 84, .18);
  color: #63d39b;
}

.doc-code pre {
  margin: 0 !important;
  border-radius: 0;
  background: #1f2328;
  color: #e6edf3;
  padding: .9rem 1rem 1rem 1rem;
  overflow: auto;
}

.doc-code-php {
  border-color: rgba(13, 110, 253, .55);
}

.doc-code-javascript,
.doc-code-js {
  border-color: rgba(255, 193, 7, .55);
}

.doc-code-html {
  border-color: rgba(25, 135, 84, .55);
}

.doc-inline-code {
  font-family: var(--bs-font-monospace);
  font-size: .925em;
  color: #d63384;
}

.doc-list {
  margin: 0;
  padding-left: 1.1rem;
  line-height: 1.8;
}

.doc-list li + li {
  margin-top: .25rem;
}

.ai-block {
  white-space: pre-wrap;
  overflow-wrap: anywhere;
  word-break: break-word;
}

.hl-keyword { color: #ff7b72; }
.hl-function { color: #d2a8ff; }
.hl-variable { color: #ffa657; }
.hl-comment { color: #8b949e; }
.hl-number { color: #79c0ff; }

@media (max-width: 991.98px) {
  .docs-sidebar-stick {
    position: static;
    height: auto;
  }
}
</style>

<section id="intro" class="doc-section" data-doc-title="Wprowadzenie" data-doc-keywords="framework php javascript html bootstrap binding app pages datas public routing layout component api db logs tabs modals animations">
  <div class="doc-section-header">
    <div class="doc-section-title-strong">Wprowadzenie</div>
    <p>CookedFramework łączy prosty routing PHP, renderowanie danych przez binding i gotowe helpery do najczęściej używanych elementów aplikacji. Strony są ładowane z folderu <code class="doc-inline-code">app/pages</code>, wspólne układy są trzymane w layoutach i componentach, a zasoby publiczne trafiają do <code class="doc-inline-code">public</code>.</p>
  </div>

  <?php
  docsHero(
      'Praca z jedną stroną od początku do końca',
      'Najczęstszy sposób pracy polega na utworzeniu pliku strony, wyrenderowaniu podstawowego HTML i przekazaniu danych do frontendu przez pageEnd. Binding upraszcza aktualizację widoku, bo eliminuje ręczne budowanie DOM dla list i bloków danych. Dzięki temu HTML pozostaje czytelny, a JavaScript zajmuje się tylko pobieraniem i podmianą danych.',
      <<<'PHP'
<?php
pageStart('Panel najemcy');
?>

<div class="card">
  <div class="card-body">
    <h1 class="h3 mb-3">Panel najemcy</h1>

    <div binding="tenant">
      <div class="fw-semibold">{{name}}</div>
      <div class="text-muted">{{email}}</div>
    </div>
  </div>
</div>

<?php
pageEnd([
  'tenant' => [
    'name' => 'Jan Kowalski',
    'email' => 'jan@example.com',
  ],
]);
?>
PHP,
      'php',
      ['app/pages', 'pageStart', 'pageEnd', 'binding', 'public', 'datas'],
      [
          'Jeśli dane są znane przy ładowaniu strony, najwygodniej przekazać je w pageEnd i użyć defaultBinding.',
          'Jeśli dane mają zmieniać się po stronie JavaScript, użyj binding i Binding.set zamiast ręcznie składać HTML.',
          'Folder datas służy do danych roboczych frameworka, a nie do treści użytkownika.'
      ]
  );
  ?>
</section>

<section id="structure" class="doc-section" data-doc-title="Struktura projektu" data-doc-keywords="struktura projektu app framework public datas logs dbScheme app db pages layouts components assets img">
  <div class="doc-section-header">
    <div class="doc-section-title-strong">Struktura projektu</div>
    <p>Projekt jest rozdzielony na kod frameworka, kod aplikacji, zasoby publiczne i dane robocze zapisywane przez sam framework. Taki podział ułatwia utrzymanie porządku i pozwala rozróżnić pliki użytkownika od plików technicznych.</p>
  </div>

  <?php
  docsHero(
      'Układ folderów i odpowiedzialności',
      'Folder app zawiera treść aplikacji: strony, layouty, componenty i pliki SQL opisujące strukturę bazy. Folder framework przechowuje kod silnika. Folder public udostępnia pliki dostępne z przeglądarki. Folder datas jest zablokowany po URL i służy do logów oraz stanu technicznego frameworka.',
      <<<'TEXT'
projekt/
│
├── index.php
├── .htaccess
├── app/
│   ├── config.php
│   ├── db/
│   ├── pages/
│   ├── layouts/
│   └── components/
├── framework/
├── public/
│   ├── assets/
│   └── img/
└── datas/
    ├── logs/
    └── dbScheme/
TEXT,
      'plaintext',
      ['app', 'framework', 'public', 'datas', 'logs', 'dbScheme']
  );
  ?>

  <?php
  docsInfoCards([
      [
          'title' => 'app/',
          'text' => 'Kod aplikacji użytkownika. To tutaj powstają strony, layouty, componenty i definicje struktury bazy.',
          'list' => [
              'app/pages — widoki i endpointy stron.',
              'app/layouts — układy body wybierane przez pageStart.',
              'app/components — współdzielone fragmenty interfejsu.',
              'app/db — pliki SQL opisujące strukturę tabel.'
          ]
      ],
      [
          'title' => 'framework/',
          'text' => 'Kod silnika frameworka. Zawiera routing, helpery PHP, warstwę DB i pliki odpowiedzialne za wspólne mechanizmy aplikacji.'
      ],
      [
          'title' => 'public/',
          'text' => 'Publiczne zasoby dostępne z poziomu przeglądarki.',
          'list' => [
              'public/assets — JavaScript, CSS i pliki używane przez frontend.',
              'public/img — obrazy i grafiki używane przez strony i componenty.'
          ]
      ],
      [
          'title' => 'datas/',
          'text' => 'Dane techniczne zapisywane przez framework. Folder nie powinien być dostępny po URL.',
          'list' => [
              'datas/logs/php.log — historia błędów PHP.',
              'datas/logs/sql.log — historia błędów SQL.',
              'datas/dbScheme/state.log — stan synchronizacji plików SQL z app/db.'
          ]
      ],
  ]);
  ?>
</section>

<section id="routing" class="doc-section" data-doc-title="Routing" data-doc-keywords="routing index htaccess app pages fwBaseUrl fwUrl fwCurrentPath route adresy">
  <div class="doc-section-header">
    <div class="doc-section-title-strong">Routing</div>
    <p>Routing opiera się na głównym pliku <code class="doc-inline-code">index.php</code>, który odbiera adres po rewrite i mapuje go na plik strony w <code class="doc-inline-code">app/pages</code>. Dzięki temu adresy pozostają czytelne, a struktura widoków jest bezpośrednio powiązana z układem katalogów.</p>
  </div>

  <?php
  docsHero(
      'Jak adres trafia do widoku',
      'Adres strony jest najpierw przepisywany przez .htaccess do głównego index.php. Następnie framework odczytuje ścieżkę z URL, czyści ją i szuka odpowiadającego pliku w app/pages. Pusty adres ładuje app/pages/index.php, a zagnieżdżone ścieżki odpowiadają podfolderom.',
      <<<'PHP'
<a href="<?= route('docs') ?>">Dokumentacja</a>
<a href="<?= route('examples/persons-crud') ?>">Przykład CRUD</a>
PHP,
      'php',
      ['index.php', '.htaccess', 'app/pages', 'route', 'fwUrl']
  );
  ?>

  <div class="doc-grid">
    <?php
    docsFunctionCard(
        'Funkcja PHP',
        'route',
        'route($path = \'\', $query = []): string',
        'Buduje bezpieczny adres URL do użycia w HTML. Łączy ścieżkę wewnętrzną z bazowym adresem aplikacji i w razie potrzeby dodaje query string.',
        [
            ['name' => '$path', 'type' => 'string', 'description' => 'Ścieżka wewnętrzna aplikacji.'],
            ['name' => '$query', 'type' => 'array', 'description' => 'Opcjonalne parametry URL.'],
        ],
        'Gotowy, bezpieczny adres do użycia np. w href.',
        [
            <<<'PHP'
<a href="<?= route('docs') ?>">Dokumentacja</a>
<a href="<?= route('examples/search-list', ['q' => 'woda']) ?>">Szukaj</a>
PHP
        ],
        'php'
    );

    docsFunctionCard(
        'Funkcja PHP',
        'fwBaseUrl',
        'fwBaseUrl(): string',
        'Zwraca bazowy adres aplikacji. Przydaje się wtedy, gdy chcesz odwołać się do wewnętrznej ścieżki poza helperem route.',
        [],
        'Bazowy adres aplikacji.',
        [
            <<<'PHP'
$base = fwBaseUrl();
echo $base;
PHP
        ],
        'php'
    );

    docsFunctionCard(
        'Funkcja PHP',
        'fwUrl',
        'fwUrl($path = \'\'): string',
        'Buduje pełny adres wewnętrzny aplikacji. To niższy poziom niż route i najczęściej przydaje się poza HTML, np. przy generowaniu ścieżek roboczych.',
        [
            ['name' => '$path', 'type' => 'string', 'description' => 'Ścieżka wewnętrzna aplikacji.'],
        ],
        'Pełny adres URL.',
        [
            <<<'PHP'
$url = fwUrl('functions/binding-js');
echo $url;
PHP
        ],
        'php'
    );

    docsFunctionCard(
        'Funkcja PHP',
        'fwCurrentPath',
        'fwCurrentPath(): string',
        'Zwraca aktualną ścieżkę widoku bez bazowego katalogu aplikacji. Ułatwia zaznaczanie aktywnego elementu menu lub warunkowe renderowanie widoku.',
        [],
        'Aktualna ścieżka strony.',
        [
            <<<'PHP'
$current = fwCurrentPath();
PHP
        ],
        'php'
    );
    ?>
  </div>
</section>

<section id="create-pages" class="doc-section" data-doc-title="Tworzenie stron" data-doc-keywords="pageStart pageEnd strony layouts page data binding templateData body content app pages">
  <div class="doc-section-header">
    <div class="doc-section-title-strong">Tworzenie stron</div>
    <p>Każda strona jest zwykłym plikiem PHP. Framework narzuca tylko prosty rytm pracy: rozpoczęcie widoku przez <code class="doc-inline-code">pageStart</code>, zawartość HTML/PHP oraz zakończenie przez <code class="doc-inline-code">pageEnd</code>.</p>
  </div>

  <?php
  docsHero(
      'Jedna strona, jeden czytelny przepływ',
      'W praktyce strona najczęściej wybiera layout, renderuje treść HTML, a na końcu przekazuje dane do frontendowych helperów i defaultBinding. Dzięki temu plik strony pozostaje kompletny i można go czytać od góry do dołu bez szukania logiki po wielu warstwach.',
      <<<'PHP'
<?php
pageStart('Rozliczenia', 'default', [
  'activeMenu' => 'settlements',
]);
?>

<div class="card">
  <div class="card-body">
    <h1 class="h3 mb-3">Rozliczenia</h1>
    <div defaultBinding="summary">
      <div class="fw-semibold">{{title}}</div>
      <div class="text-muted">{{period}}</div>
    </div>
  </div>
</div>

<?php
pageEnd([
  'summary' => [
    'title' => 'Rozliczenie mediów',
    'period' => 'Styczeń 2026',
  ],
]);
?>
PHP,
      'php',
      ['pageStart', 'pageEnd', 'layout', 'defaultBinding']
  );
  ?>

  <div class="doc-grid">
    <?php
    docsFunctionCard(
        'Funkcja PHP',
        'pageStart',
        'pageStart($title = \'\', $template = null, $templateData = []): void',
        'Rozpoczyna renderowanie strony, wybiera layout i przekazuje dane potrzebne szablonowi. To miejsce na tytuł strony, layout oraz dodatkowe dane używane przez układ.',
        [
            ['name' => '$title', 'type' => 'string', 'description' => 'Tytuł strony.'],
            ['name' => '$template', 'type' => 'string|null', 'description' => 'Nazwa layoutu z app/layouts.'],
            ['name' => '$templateData', 'type' => 'array', 'description' => 'Dane pomocnicze dla layoutu.'],
        ],
        'Rozpoczyna buforowanie i renderowanie strony.',
        [
            <<<'PHP'
<?php
pageStart('Dokumentacja', 'docs', [
  'activeMenu' => 'docs',
]);
?>
PHP
        ],
        'php'
    );

    docsFunctionCard(
        'Funkcja PHP',
        'pageEnd',
        'pageEnd($pageData = []): void',
        'Kończy renderowanie strony i przekazuje dane do frontendu. To najwygodniejsze miejsce na dane dla defaultBinding albo dla helpera getPageData po stronie JavaScript.',
        [
            ['name' => '$pageData', 'type' => 'array', 'description' => 'Dane przekazywane do strony i bindingu.'],
        ],
        'Kończy renderowanie strony.',
        [
            <<<'PHP'
<?php
pageEnd([
  'users' => $users,
  'summary' => $summary,
]);
?>
PHP
        ],
        'php'
    );
    ?>
  </div>
</section>

<section id="config" class="doc-section" data-doc-title="Config" data-doc-keywords="config fwConfig app config debug save_errors menu_items default_template db">
  <div class="doc-section-header">
    <div class="doc-section-title-strong">Config</div>
    <p>Plik <code class="doc-inline-code">app/config.php</code> przechowuje ustawienia aplikacji i mechanizmów frameworka. To tutaj określasz tytuł aplikacji, domyślny layout, konfigurację bazy i zachowanie logów.</p>
  </div>

  <?php
  docsHero(
      'Jedno miejsce na ustawienia aplikacji',
      'Konfiguracja jest zwracana jako zwykła tablica PHP. Framework odczytuje ją podczas startu i udostępnia przez helper fwConfig. Dzięki temu ustawienia pozostają proste, przewidywalne i gotowe do użycia w stronach, layoutach oraz warstwie DB.',
      <<<'PHP'
<?php
return [
  'title' => 'CookedFramework',
  'default_template' => 'default',
  'debug' => true,
  'save_errors' => true,
  'php_log_file' => 'php.log',
  'sql_log_file' => 'sql.log',
  'db' => [
    'dsn' => 'mysql:host=localhost;dbname=app;charset=utf8mb4',
    'user' => 'root',
    'pass' => '',
  ],
];
PHP,
      'php',
      ['app/config.php', 'debug', 'save_errors', 'db']
  );
  ?>

  <div class="doc-grid">
    <?php
    docsFunctionCard(
        'Funkcja PHP',
        'fwConfig',
        'fwConfig($key = null, $default = null)',
        'Odczytuje konfigurację całej aplikacji albo pojedynczą wartość z configu. Dzięki temu nie trzeba sięgać bezpośrednio do globalnych zmiennych.',
        [
            ['name' => '$key', 'type' => 'string|null', 'description' => 'Klucz z konfiguracji.'],
            ['name' => '$default', 'type' => 'mixed', 'description' => 'Wartość domyślna zwracana, gdy klucz nie istnieje.'],
        ],
        'Całą konfigurację albo pojedynczą wartość.',
        [
            <<<'PHP'
$title = fwConfig('title', 'Aplikacja');
$debug = fwConfig('debug', false);
PHP
        ],
        'php'
    );
    ?>
  </div>
</section>

<section id="binding" class="doc-section" data-doc-title="Binding" data-doc-keywords="binding defaultBinding innerBinding template Binding.set placeholder listy dane dom renderowanie">
  <div class="doc-section-header">
    <div class="doc-section-title-strong">Binding</div>
    <p>Binding jest podstawowym sposobem renderowania danych w widoku. Ułatwia podmianę treści bez ręcznego budowania HTML i pozwala utrzymać czytelny podział między strukturą strony a danymi.</p>
  </div>

  <?php
  docsHero(
      'Dane trafiają do istniejącego HTML',
      'Zamiast ręcznie tworzyć elementy przez JavaScript, binding aktualizuje przygotowany wcześniej HTML. Ten sam mechanizm obsługuje zarówno dane startowe przekazane przez pageEnd, jak i dane pobrane później przez API. Dzięki temu widok jest spójny, a kod łatwiej utrzymać i rozszerzać.',
      <<<'HTML'
<div binding="items">
  <div template class="border-bottom py-2">
    <div class="fw-semibold">{{name}}</div>
    <div class="text-muted small">{{unit}}</div>
  </div>
</div>
HTML,
      'html',
      ['defaultBinding', 'binding', 'innerBinding', 'template', 'Binding.set'],
      [
          'defaultBinding najlepiej sprawdza się przy danych znanych już podczas ładowania strony.',
          'binding i Binding.set są wygodne wtedy, gdy dane przychodzą z API lub zmieniają się po stronie JavaScript.',
          'template stosuj do list. Dla pojedynczych bloków nie jest potrzebny.'
      ]
  );
  ?>

  <div class="doc-grid">
    <?php
    docsFunctionCard(
        'HTML',
        'defaultBinding',
        'defaultBinding="nazwa"',
        'Automatycznie łączy element z danymi przekazanymi w pageEnd. To najprostsza forma renderowania danych startowych na stronie.',
        [
            ['name' => 'nazwa', 'type' => 'string', 'description' => 'Klucz z tablicy przekazanej do pageEnd.'],
        ],
        'Element zostaje wypełniony danymi przy renderowaniu strony.',
        [
            <<<'HTML'
<div defaultBinding="summary">
  <div>{{title}}</div>
  <div>{{period}}</div>
</div>
HTML,
            <<<'PHP'
<?php
pageEnd([
  'summary' => [
    'title' => 'Rozliczenie',
    'period' => 'Luty 2026',
  ],
]);
?>
PHP
        ],
        'html'
    );

    docsFunctionCard(
        'HTML',
        'binding',
        'binding="nazwa"',
        'Oznacza obszar aktualizowany ręcznie przez JavaScript. Sam binding nie pobiera danych — oczekuje ich przez Binding.set.',
        [
            ['name' => 'nazwa', 'type' => 'string', 'description' => 'Klucz, pod którym JavaScript ustawia dane.'],
        ],
        'Element może zostać odświeżony w dowolnym momencie działania strony.',
        [
            <<<'HTML'
<div binding="tenant">
  <div>{{name}}</div>
  <div>{{email}}</div>
</div>
HTML,
            <<<'JAVASCRIPT'
Binding.set('tenant', {
  name: 'Jan Kowalski',
  email: 'jan@example.com'
});
JAVASCRIPT
        ],
        'html'
    );

    docsFunctionCard(
        'HTML',
        'innerBinding',
        'innerBinding="ścieżka"',
        'Renderuje dane zagnieżdżone wewnątrz bieżącego obiektu. Przydaje się, gdy jeden rekord zawiera kolejną listę lub blok obiektów.',
        [
            ['name' => 'ścieżka', 'type' => 'string', 'description' => 'Ścieżka do zagnieżdżonych danych.'],
        ],
        'Dzieci elementu są renderowane na podstawie danych z bieżącego obiektu.',
        [
            <<<'HTML'
<div template class="mb-3">
  <div class="fw-semibold">{{number}}</div>

  <div innerBinding="items">
    <div template class="small text-muted">{{name}}</div>
  </div>
</div>
HTML
        ],
        'html'
    );

    docsFunctionCard(
        'HTML',
        'template',
        'template',
        'Wskazuje element wzorcowy używany do renderowania listy. Framework klonuje go dla kolejnych rekordów i podstawia dane do placeholderów.',
        [],
        'Element staje się wzorcem dla listy.',
        [
            <<<'HTML'
<div binding="items">
  <div template class="border rounded p-3 mb-2">
    <div>{{name}}</div>
  </div>
</div>
HTML
        ],
        'html'
    );

    docsFunctionCard(
        'Funkcja JS',
        'Binding.set',
        'Binding.set(name, value): void',
        'Ustawia dane dla bindingu po stronie JavaScript. To podstawowy sposób odświeżania widoku po odpowiedzi z API albo po lokalnej zmianie danych.',
        [
            ['name' => 'name', 'type' => 'string', 'description' => 'Nazwa bindingu.'],
            ['name' => 'value', 'type' => 'any', 'description' => 'Obiekt, tablica albo wartość do wyrenderowania.'],
        ],
        'Nie zwraca wartości.',
        [
            <<<'JAVASCRIPT'
const data = await get('api::list');
Binding.set('items', data.items || []);
JAVASCRIPT
        ],
        'javascript'
    );
    ?>
  </div>
</section>

<section id="events" class="doc-section" data-doc-title="Eventy" data-doc-keywords="click change edit keydown keyup clickData changeData editData setText hide getValue hasItems onReady eventy helpery js">
  <div class="doc-section-header">
    <div class="doc-section-title-strong">Eventy</div>
    <p>Helpery eventów upraszczają obsługę kliknięć, zmian formularzy i pracy z klawiaturą. Działają delegacyjnie i pozwalają pisać krótszy, bardziej spójny kod niż ręczne addEventListener dla każdego elementu osobno.</p>
  </div>

  <?php
  docsHero(
      'Jednolity styl obsługi interakcji',
      'Eventy w CookedFramework mają podobną składnię i ten sam sposób przekazywania danych. Dzięki temu można mieszać obsługę kliknięć, edycji i klawiatury bez zmiany stylu kodu. Dodatkowe helpery, takie jak setText czy getValue, skracają najczęstsze operacje na formularzach i prostych blokach treści.',
      <<<'JAVASCRIPT'
function loadItems()
{

}

edit('searchText', async () => {
  await loadItems();
});

click('btnClear', () => {
  setText('searchInfo', 'Wyniki zostały wyczyszczone.');
});
JAVASCRIPT,
      'javascript',
      ['click', 'change', 'edit', 'keyDown', 'keyUp', 'setText', 'getValue', 'hide']
  );
  ?>

  <div class="doc-grid">
    <?php
    docsFunctionCard('Funkcja JS', 'click', 'click(selector, handler): void', 'Obsługuje kliknięcie delegacyjnie na podstawie selektora lub ID. To podstawowy helper do przycisków i linków sterujących widokiem.', [
        ['name' => 'selector', 'type' => 'string', 'description' => 'Selektor CSS albo ID elementu.'],
        ['name' => 'handler', 'type' => 'function', 'description' => 'Funkcja wywoływana po kliknięciu.'],
    ], 'Nie zwraca wartości.', [
        <<<'JAVASCRIPT'
click('btnSave', async () => {
  await send('api::save', { id: 15 });
});
JAVASCRIPT
    ], 'javascript');

    docsFunctionCard('Funkcja JS', 'clickData', 'clickData(name, handler): void', 'Obsługuje kliknięcia na elementach oznaczonych atrybutem. Framework odczytuje zarówno name, jak i data-name.', [
        ['name' => 'name', 'type' => 'string', 'description' => 'Nazwa atrybutu.'],
        ['name' => 'handler', 'type' => 'function', 'description' => 'Funkcja wywoływana z wartością atrybutu.'],
    ], 'Nie zwraca wartości.', [
        <<<'HTML'
<button data-delete-person-id="15">Usuń</button>
HTML,
        <<<'JAVASCRIPT'
clickData('delete-person-id', async (value) => {
  await send('api::delete', { id: value });
});
JAVASCRIPT
    ], 'javascript');

    docsFunctionCard('Funkcja JS', 'change', 'change(selector, handler): void', 'Obsługuje zmianę wartości po zakończeniu edycji pola. Przydaje się np. przy selectach, checkboxach i formularzach, gdzie reakcja nie musi następować po każdym znaku.', [
        ['name' => 'selector', 'type' => 'string', 'description' => 'Selektor CSS albo ID elementu.'],
        ['name' => 'handler', 'type' => 'function', 'description' => 'Funkcja obsługująca zmianę.'],
    ], 'Nie zwraca wartości.', [
        <<<'JAVASCRIPT'
change('statusSelect', (element) => {
  setText('statusLabel', element.value);
});
JAVASCRIPT
    ], 'javascript');

    docsFunctionCard('Funkcja JS', 'changeData', 'changeData(name, handler): void', 'Wersja atrybutowa helpera change. Sprawdza atrybut w dwóch wariantach i przekazuje jego wartość do callbacka.', [
        ['name' => 'name', 'type' => 'string', 'description' => 'Nazwa atrybutu.'],
        ['name' => 'handler', 'type' => 'function', 'description' => 'Funkcja obsługująca zmianę.'],
    ], 'Nie zwraca wartości.', [
        <<<'JAVASCRIPT'
changeData('tenant-id', (value, element) => {
  console.log(value, element.value);
});
JAVASCRIPT
    ], 'javascript');

    docsFunctionCard('Funkcja JS', 'edit', 'edit(selector, handler): void', 'Obsługuje edycję pola na bieżąco przez event input. To wygodny wybór dla wyszukiwarek, filtrów i podglądu danych aktualizowanego podczas wpisywania.', [
        ['name' => 'selector', 'type' => 'string', 'description' => 'Selektor CSS albo ID elementu.'],
        ['name' => 'handler', 'type' => 'function', 'description' => 'Funkcja wywoływana podczas edycji.'],
    ], 'Nie zwraca wartości.', [
        <<<'JAVASCRIPT'
edit('searchText', async () => {
  await loadItems(getValue('searchText').trim());
});
JAVASCRIPT
    ], 'javascript');

    docsFunctionCard('Funkcja JS', 'editData', 'editData(name, handler): void', 'Wersja atrybutowa helpera edit. Dobrze sprawdza się przy formularzach generowanych z listy albo przy polach budowanych przez binding.', [
        ['name' => 'name', 'type' => 'string', 'description' => 'Nazwa atrybutu.'],
        ['name' => 'handler', 'type' => 'function', 'description' => 'Funkcja wywoływana podczas edycji.'],
    ], 'Nie zwraca wartości.', [
        <<<'JAVASCRIPT'
editData('rate-name', (value, element) => {
  console.log(value, element.value);
});
JAVASCRIPT
    ], 'javascript');

    docsFunctionCard('Funkcja JS', 'keyDown', 'keyDown(selector, handler): void', 'Obsługuje naciśnięcie klawisza. Przydaje się np. do skrótów klawiaturowych, wyszukiwania po Enter lub sterowania formularzem.', [
        ['name' => 'selector', 'type' => 'string', 'description' => 'Selektor CSS albo ID elementu.'],
        ['name' => 'handler', 'type' => 'function', 'description' => 'Funkcja wywoływana przy keydown.'],
    ], 'Nie zwraca wartości.', [
        <<<'JAVASCRIPT'
keyDown('searchText', (element, e) => {
  if (e.key === 'Enter') {
    console.log(element.value);
  }
});
JAVASCRIPT
    ], 'javascript');

    docsFunctionCard('Funkcja JS', 'keyUp', 'keyUp(selector, handler): void', 'Obsługuje zwolnienie klawisza. Pozwala reagować po zakończeniu wpisywania znaku albo po puszczeniu klawisza sterującego.', [
        ['name' => 'selector', 'type' => 'string', 'description' => 'Selektor CSS albo ID elementu.'],
        ['name' => 'handler', 'type' => 'function', 'description' => 'Funkcja wywoływana przy keyup.'],
    ], 'Nie zwraca wartości.', [
        <<<'JAVASCRIPT'
keyUp('searchText', (element) => {
  console.log(element.value);
});
JAVASCRIPT
    ], 'javascript');

    docsFunctionCard('Funkcja JS', 'keyDownData / keyUpData', 'keyDownData(name, handler): void / keyUpData(name, handler): void', 'Atrybutowe wersje helperów klawiaturowych. Ułatwiają pracę z polami generowanymi dynamicznie i z listami formularzy.', [
        ['name' => 'name', 'type' => 'string', 'description' => 'Nazwa atrybutu.'],
        ['name' => 'handler', 'type' => 'function', 'description' => 'Funkcja wywoływana przy keydown lub keyup.'],
    ], 'Nie zwraca wartości.', [
        <<<'JAVASCRIPT'
keyUpData('line-id', (value, element) => {
  console.log(value, element.value);
});
JAVASCRIPT
    ], 'javascript');

    docsFunctionCard('Funkcja JS', 'setText', 'setText(selector, value): void', 'Ustawia tekst elementu bez ręcznego pobierania go z DOM i bez sprawdzania, czy element istnieje.', [
        ['name' => 'selector', 'type' => 'string', 'description' => 'Selektor CSS albo ID elementu.'],
        ['name' => 'value', 'type' => 'string', 'description' => 'Nowa treść tekstowa.'],
    ], 'Nie zwraca wartości.', [
        <<<'JAVASCRIPT'
setText('resultBox', 'Dane zostały zapisane.');
JAVASCRIPT
    ], 'javascript');

    docsFunctionCard('Funkcja JS', 'hide', 'hide(selector, hidden = true): void', 'Ukrywa lub pokazuje element, przywracając poprzedni display. To wygodniejsza forma niż ręczne operowanie na style.display.', [
        ['name' => 'selector', 'type' => 'string', 'description' => 'Selektor CSS albo ID elementu.'],
        ['name' => 'hidden', 'type' => 'boolean', 'description' => 'Określa, czy element ma być ukryty.'],
    ], 'Nie zwraca wartości.', [
        <<<'JAVASCRIPT'
hide('advancedBox', true);
hide('advancedBox', false);
JAVASCRIPT
    ], 'javascript');

    docsFunctionCard('Funkcja JS', 'getValue', 'getValue(selector, defaultValue = ""): string', 'Pobiera wartość pola formularza. Jeśli element nie istnieje, zwraca wartość domyślną, co upraszcza walidację i wysyłkę formularzy.', [
        ['name' => 'selector', 'type' => 'string', 'description' => 'Selektor CSS albo ID elementu.'],
        ['name' => 'defaultValue', 'type' => 'string', 'description' => 'Wartość zwracana, gdy element nie istnieje.'],
    ], 'Wartość pola albo wartość domyślna.', [
        <<<'JAVASCRIPT'
const name = getValue('nameInput');
const email = getValue('emailInput');
JAVASCRIPT
    ], 'javascript');

    docsFunctionCard('Funkcja JS', 'hasItems', 'hasItems(value): boolean', 'Sprawdza, czy przekazana wartość jest tablicą i czy zawiera elementy. Ułatwia obsługę pustych stanów i wyników API.', [
        ['name' => 'value', 'type' => 'any', 'description' => 'Wartość do sprawdzenia.'],
    ], 'true dla niepustej tablicy, w pozostałych przypadkach false.', [
        <<<'JAVASCRIPT'
if (!hasItems(data.items)) {
  setText('emptyState', 'Brak wyników.');
}
JAVASCRIPT
    ], 'javascript');

    docsFunctionCard('Funkcja JS', 'onReady', 'onReady(callback): void', 'Uruchamia kod po gotowym DOM albo od razu, jeśli dokument jest już gotowy. To wygodny helper bezpieczeństwa dla fragmentów, które rzeczywiście muszą poczekać na DOM.', [
        ['name' => 'callback', 'type' => 'function', 'description' => 'Funkcja uruchamiana po gotowym DOM.'],
    ], 'Nie zwraca wartości.', [
        <<<'JAVASCRIPT'
onReady(() => {
  console.log('DOM jest gotowy.');
});
JAVASCRIPT
    ], 'javascript', [
        'Jeśli skrypt jest ładowany na dole strony albo przez defer i nie potrzebuje dodatkowego oczekiwania, można pisać kod bez onReady.'
    ]);
    ?>
  </div>
</section>

<section id="http-api" class="doc-section" data-doc-title="Http i API" data-doc-keywords="get getRaw send input output error onapi api http json request response">
  <div class="doc-section-header">
    <div class="doc-section-title-strong">Http i API</div>
    <p>Framework upraszcza komunikację między frontendem i PHP. Po stronie JavaScript pobierasz dane helperami get, getRaw i send, a po stronie PHP korzystasz z input, output, error i onapi do obsługi jednej strony z częścią API.</p>
  </div>

  <?php
  docsHero(
      'Jedna strona może mieć własne API',
      'W prostych widokach wygodnie jest obsługiwać akcje API w tym samym pliku strony. Dzięki temu logika listy, formularza i zapisu pozostaje blisko siebie. JavaScript może korzystać ze skrótu api::nazwa, a framework sam zamieni go na poprawny adres bieżącej strony.',
      <<<'PHP'
<?php
if (onapi('list')) {
  output([
    'items' => DB_SELECT('persons', ['id', 'name', 'email'])
  ]);
}
?>
PHP,
      'php',
      ['get', 'send', 'input', 'output', 'onapi']
  );
  ?>

  <div class="doc-grid">
    <?php
    docsFunctionCard('Funkcja JS', 'get', 'get(url, params = {}): Promise<any>', 'Pobiera JSON i od razu zwraca data z odpowiedzi.', [
        ['name' => 'url', 'type' => 'string', 'description' => 'Adres docelowy albo skrót api::nazwa.'],
        ['name' => 'params', 'type' => 'object', 'description' => 'Opcjonalne parametry URL.'],
    ], 'Promise z odpowiedzią data.', [
        <<<'JAVASCRIPT'
const data = await get('api::list', { q: 'woda' });
Binding.set('items', data.items || []);
JAVASCRIPT
    ], 'javascript');

    docsFunctionCard('Funkcja JS', 'getRaw', 'getRaw(url, params = {}): Promise<string>', 'Pobiera odpowiedź tekstową bez automatycznego parsowania JSON. Przydaje się wtedy, gdy endpoint zwraca zwykły tekst, fragment HTML albo kod źródłowy.', [
        ['name' => 'url', 'type' => 'string', 'description' => 'Adres docelowy albo skrót api::nazwa.'],
        ['name' => 'params', 'type' => 'object', 'description' => 'Opcjonalne parametry URL.'],
    ], 'Promise z tekstem odpowiedzi.', [
        <<<'JAVASCRIPT'
const html = await getRaw('api::preview');
document.getElementById('previewBox').innerHTML = html;
JAVASCRIPT
    ], 'javascript');

    docsFunctionCard('Funkcja JS', 'send', 'send(url, data = {}): Promise<any>', 'Wysyła dane metodą POST jako JSON i zwraca data z odpowiedzi. To podstawowy helper do zapisu formularzy i akcji wykonywanych z poziomu interfejsu.', [
        ['name' => 'url', 'type' => 'string', 'description' => 'Adres docelowy albo skrót api::nazwa.'],
        ['name' => 'data', 'type' => 'object', 'description' => 'Dane wysyłane w body requestu.'],
    ], 'Promise z odpowiedzią data.', [
        <<<'JAVASCRIPT'
await send('api::save', {
  name: getValue('nameInput'),
  email: getValue('emailInput')
});
JAVASCRIPT
    ], 'javascript');

    docsFunctionCard('Funkcja PHP', 'input', 'input(): array', 'Odczytuje dane wejściowe requestu po stronie PHP. Najczęściej służy do pobrania danych wysłanych przez send.', [], 'Tablicę z danymi wejściowymi.', [
        <<<'PHP'
$data = input();
$name = $data['name'] ?? '';
PHP
    ], 'php');

    docsFunctionCard('Funkcja PHP', 'fileInput', 'fileInput(): array', 'Odczytuje dane formularza i pliki w requestach, które korzystają z przesyłania plików. Pozwala obsłużyć upload bez ręcznego składania struktury wejściowej.', [], 'Tablicę z danymi formularza i plikami.', [
        <<<'PHP'
$data = fileInput();
$file = $data['photo'] ?? null;
PHP
    ], 'php');

    docsFunctionCard('Funkcja PHP', 'output', 'output(data): void', 'Zwraca odpowiedź JSON i kończy działanie skryptu. To najwygodniejsza forma zwracania danych z części API strony.', [
        ['name' => 'data', 'type' => 'array', 'description' => 'Dane zwracane do frontendu.'],
    ], 'Nie zwraca wartości. Kończy działanie skryptu.', [
        <<<'PHP'
output([
  'ok' => true,
  'items' => $items,
]);
PHP
    ], 'php');

    docsFunctionCard('Funkcja PHP', 'error', 'error(code, message): void', 'Zwraca ustandaryzowaną odpowiedź błędu w JSON i kończy działanie skryptu.', [
        ['name' => '$code', 'type' => 'int|string', 'description' => 'Kod błędu.'],
        ['name' => '$message', 'type' => 'string', 'description' => 'Komunikat błędu.'],
    ], 'Nie zwraca wartości. Kończy działanie skryptu.', [
        <<<'PHP'
error(400, 'Nie udało się zapisać danych.');
PHP
    ], 'php');

    docsFunctionCard('Funkcja PHP', 'onapi', 'onapi(name): bool', 'Sprawdza, czy aktualne wywołanie strony dotyczy wskazanej akcji API. Dzięki temu możesz połączyć część widokową i prostą obsługę API w jednym pliku.', [
        ['name' => '$name', 'type' => 'string', 'description' => 'Nazwa akcji API.'],
    ], 'true albo false.', [
        <<<'PHP'
if (onapi('delete')) {
  $data = input();
  DB_EXECUTE('DELETE FROM persons WHERE id = ?', [$data['id'] ?? 0]);
  output(['ok' => true]);
}
PHP
    ], 'php');
    ?>
  </div>
</section>

<section id="modals" class="doc-section" data-doc-title="Modale" data-doc-keywords="Modal show ModalInfo ModalConfirm ModalForm Field Button modal js popup">
  <div class="doc-section-header">
    <div class="doc-section-title-strong">Modale</div>
    <p>Modale w CookedFramework mają gotowy zestaw typów do informacji, potwierdzeń i formularzy. Dzięki temu nie trzeba ręcznie budować HTML okna, walidacji i przycisków za każdym razem od nowa.</p>
  </div>

  <?php
  docsHero(
      'Komunikaty, potwierdzenia i formularze w jednym stylu',
      'Framework udostępnia wspólny sposób definiowania modali. Każdy typ opiera się na polach i przyciskach, a wynik trafia z powrotem do JavaScript przez Promise. To upraszcza obsługę zapisów, potwierdzeń usunięcia i krótkich formularzy.',
      <<<'JAVASCRIPT'
click('btnAddPerson', async () => {
  const data = await new ModalForm(
    'Nowa osoba',
    [
      Field.text('name', 'Imię i nazwisko', 'np. Jan Kowalski', [[true, 'To pole nie może być puste']]),
      Field.email('email', 'E-mail', 'np. jan@example.com', [['^[^\\s@]+@[^\\s@]+\\.[^\\s@]+$', 'Podaj poprawny adres e-mail']])
    ],
    [
      Button.close('Anuluj', false, 'btn-secondary'),
      Button.submit('Zapisz', 'btn-primary')
    ]
  ).show();

  console.log(data);
});
JAVASCRIPT,
      'javascript',
      ['ModalInfo', 'ModalConfirm', 'ModalForm', 'Field', 'Button']
  );
  ?>

  <div class="doc-grid">
    <?php
    docsFunctionCard('Konstruktor', 'ModalInfo', 'new ModalInfo(title, text, buttons)', 'Tworzy modal informacyjny. Dobrze sprawdza się do komunikatów po zapisie, błędów i krótkich informacji dla użytkownika.', [
        ['name' => 'title', 'type' => 'string', 'description' => 'Tytuł modala.'],
        ['name' => 'text', 'type' => 'string', 'description' => 'Treść komunikatu.'],
        ['name' => 'buttons', 'type' => 'array', 'description' => 'Lista przycisków.'],
    ], 'Obiekt modala gotowy do wyświetlenia.', [
        <<<'JAVASCRIPT'
await new ModalInfo('Zapis zakończony', 'Dane zostały zapisane.').show();
JAVASCRIPT
    ], 'javascript');

    docsFunctionCard('Konstruktor', 'ModalConfirm', 'new ModalConfirm(title, text, buttons)', 'Tworzy modal potwierdzenia. Najczęściej służy do operacji, które użytkownik powinien świadomie zatwierdzić, np. usunięcia rekordu.', [
        ['name' => 'title', 'type' => 'string', 'description' => 'Tytuł modala.'],
        ['name' => 'text', 'type' => 'string', 'description' => 'Treść pytania.'],
        ['name' => 'buttons', 'type' => 'array', 'description' => 'Lista przycisków.'],
    ], 'Obiekt modala gotowy do wyświetlenia.', [
        <<<'JAVASCRIPT'
const ok = await new ModalConfirm('Usuń osobę', 'Czy na pewno usunąć rekord?').show();
JAVASCRIPT
    ], 'javascript');

    docsFunctionCard('Konstruktor', 'ModalForm', 'new ModalForm(title, fields, buttons)', 'Tworzy modal formularza. To wygodny sposób na krótkie formularze dodawania i edycji bez przeładowania strony.', [
        ['name' => 'title', 'type' => 'string', 'description' => 'Tytuł modala.'],
        ['name' => 'fields', 'type' => 'array', 'description' => 'Lista pól formularza.'],
        ['name' => 'buttons', 'type' => 'array', 'description' => 'Lista przycisków.'],
    ], 'Obiekt modala gotowy do wyświetlenia.', [
        <<<'JAVASCRIPT'
const data = await new ModalForm('Nowa osoba', [
  Field.text('name', 'Imię i nazwisko', 'np. Jan Kowalski'),
  Field.email('email', 'E-mail', 'np. jan@example.com')
], [
  Button.close('Anuluj', false, 'btn-secondary'),
  Button.submit('Zapisz', 'btn-primary')
]).show();
JAVASCRIPT
    ], 'javascript');

    docsFunctionCard('Funkcja JS', 'Field.text / Field.number / Field.email / Field.none', 'Field.text(...), Field.number(...), Field.email(...), Field.none(...)', 'Buduje pola używane wewnątrz modalnych formularzy. Dzięki temu formularz składa się z prostych deklaracji, a nie ręcznego HTML.', [], 'Obiekt pola dla modala.', [
        <<<'JAVASCRIPT'
const fields = [
  Field.text('name', 'Imię i nazwisko', 'np. Jan Kowalski'),
  Field.email('email', 'E-mail', 'np. jan@example.com'),
  Field.none('Dane będą widoczne na liście po zapisaniu.', 'text-muted')
];
JAVASCRIPT
    ], 'javascript');

    docsFunctionCard('Funkcja JS', 'Button.button / Button.submit / Button.close / Button.none', 'Button.button(...), Button.submit(...), Button.close(...), Button.none(...)', 'Buduje przyciski modala i określa ich działanie. To spójny sposób definiowania zapisów, anulowania i przycisków pomocniczych.', [], 'Obiekt przycisku dla modala.', [
        <<<'JAVASCRIPT'
const buttons = [
  Button.close('Anuluj', false, 'btn-secondary'),
  Button.submit('Zapisz', 'btn-primary')
];
JAVASCRIPT
    ], 'javascript');

    docsFunctionCard('Obiekt', 'Modal', 'Modal.show(modal) / modal.show(): Promise<any>', 'Wyświetla gotowy modal i zwraca wynik działania użytkownika. To wspólny punkt dla wszystkich typów modali.', [], 'Promise z wynikiem działania modala.', [
        <<<'JAVASCRIPT'
const result = await new ModalInfo('Gotowe', 'Zmiany zostały zapisane.').show();
JAVASCRIPT
    ], 'javascript');
    ?>
  </div>
</section>

<section id="tabs" class="doc-section" data-doc-title="Zakładki" data-doc-keywords="tabs set-tab tab new Tabs display none zakładki">
  <div class="doc-section-header">
    <div class="doc-section-title-strong">Zakładki</div>
    <p>Zakładki pozwalają dzielić widok na czytelne sekcje bez ręcznego pisania logiki przełączania. HTML określa strukturę, a obiekt Tabs odpowiada za aktywną zakładkę i nawigację między panelami.</p>
  </div>

  <?php
  docsHero(
      'Czytelny podział treści na sekcje',
      'Mechanizm tabs opiera się na prostych atrybutach HTML i jednej klasie JavaScript. Dzięki temu można przełączać sekcje bez zależności od bootstrapa w samej logice przełączania. Widok pozostaje prosty, a sterowanie zakładkami można rozszerzyć o własne przyciski lub skrypty.',
      <<<'HTML'
<div tabs>
  <div class="d-flex gap-2 mb-3">
    <button set-tab="summary" class="btn btn-outline-primary active">Podsumowanie</button>
    <button set-tab="meters" class="btn btn-outline-primary">Liczniki</button>
  </div>

  <div tab="summary">Zawartość podsumowania</div>
  <div tab="meters" style="display:none;">Zawartość liczników</div>
</div>
HTML,
      'html',
      ['tabs', 'set-tab', 'tab', 'Tabs']
  );
  ?>

  <div class="doc-grid">
    <?php
    docsFunctionCard('HTML', 'tabs / set-tab / tab', 'tabs, set-tab="id", tab="id"', 'Atrybuty HTML budujące strukturę zakładek. tabs oznacza kontener, set-tab przycisk przełączający, a tab panel z treścią.', [], 'Nie zwraca wartości.', [
        <<<'HTML'
<div tabs>
  <button set-tab="invoices">Faktury</button>
  <button set-tab="settlements">Rozliczenia</button>

  <div tab="invoices">Treść faktur</div>
  <div tab="settlements" style="display:none;">Treść rozliczeń</div>
</div>
HTML
    ], 'html');

    docsFunctionCard('Konstruktor', 'Tabs', 'new Tabs(container, startTab = null)', 'Tworzy obiekt obsługujący zakładki dla wskazanego kontenera. Przydaje się wtedy, gdy chcesz sterować zakładkami z JavaScript albo przełączać je programowo.', [
        ['name' => 'container', 'type' => 'string|Element', 'description' => 'Kontener zakładek.'],
        ['name' => 'startTab', 'type' => 'string|number|null', 'description' => 'Opcjonalna zakładka startowa.'],
    ], 'Obiekt Tabs.', [
        <<<'JAVASCRIPT'
const tabs = new Tabs('billingTabs');
JAVASCRIPT
    ], 'javascript');

    docsFunctionCard('Funkcja JS', 'Tabs.set', 'tabs.set(tab): void', 'Aktywuje wskazaną zakładkę po identyfikatorze albo indeksie.', [
        ['name' => 'tab', 'type' => 'string|number', 'description' => 'Identyfikator albo indeks zakładki.'],
    ], 'Nie zwraca wartości.', [
        <<<'JAVASCRIPT'
tabs.set('meters');
JAVASCRIPT
    ], 'javascript');

    docsFunctionCard('Funkcja JS', 'Tabs.get / Tabs.getIndex / Tabs.next / Tabs.prev', 'tabs.get(): string / tabs.getIndex(): number / tabs.next(): void / tabs.prev(): void', 'Zestaw pomocniczych metod do odczytu i zmiany aktywnej zakładki.', [], 'Identyfikator, indeks albo brak wartości — zależnie od metody.', [
        <<<'JAVASCRIPT'
const activeId = tabs.get();
const activeIndex = tabs.getIndex();
tabs.next();
tabs.prev();
JAVASCRIPT
    ], 'javascript');
    ?>
  </div>
</section>

<section id="db" class="doc-section" data-doc-title="Baza danych" data-doc-keywords="db query execute get select insert update app db datas dbScheme logs sql state log auto schema">
  <div class="doc-section-header">
    <div class="doc-section-title-strong">Baza Danych</div>
    <p>Warstwa DB łączy proste helpery zapytań z automatycznym pilnowaniem struktury tabel. Framework czyta pliki SQL z <code class="doc-inline-code">app/db</code>, synchronizuje brakujące elementy przy pierwszym użyciu bazy i zapisuje swój stan oraz logi w folderze <code class="doc-inline-code">datas</code>.</p>
  </div>

  <?php
  docsHero(
      'Pliki SQL w app/db i techniczne dane w datas',
      'Definicje tabel trzymasz w app/db jako zwykłe pliki SQL. Przy pierwszym użyciu DB framework sprawdza te pliki, tworzy brakujące tabele i — jeśli definicja została rozszerzona — dodaje brakujące kolumny do istniejącej tabeli. Stan synchronizacji trafia do datas/dbScheme/state.log, a historia błędów SQL do datas/logs/sql.log.',
      <<<'TEXT'
app/db/
  persons.sql
  places.sql
  meters.sql

datas/
  dbScheme/state.log
  logs/sql.log
TEXT,
      'plaintext',
      ['app/db', 'datas/dbScheme/state.log', 'datas/logs/sql.log', 'auto schema'],
      [
          'Framework nie tworzy własnej tabeli technicznej w bazie.',
          'Stan synchronizacji i logi są zapisywane wyłącznie w plikach w datas.',
          'Zmiana istniejącej definicji tabeli może dodać brakujące kolumny, ale nie usuwa i nie zmienia automatycznie istniejących pól.'
      ]
  );
  ?>

  <div class="doc-grid">
    <?php
    docsFunctionCard('Funkcja PHP', 'DB_QUERY', 'DB_QUERY($sql, $params = []): array', 'Wykonuje zapytanie i zwraca listę rekordów. To podstawowy helper do odczytu wielu wierszy.', [
        ['name' => '$sql', 'type' => 'string', 'description' => 'Zapytanie SQL.'],
        ['name' => '$params', 'type' => 'array', 'description' => 'Parametry zapytania.'],
    ], 'Tablicę rekordów.', [
        <<<'PHP'
$persons = DB_QUERY('SELECT id, name, email FROM persons ORDER BY id DESC');
PHP
    ], 'php');

    docsFunctionCard('Funkcja PHP', 'DB_GET', 'DB_GET($sql, $params = []): ?array', 'Wykonuje zapytanie i zwraca jeden rekord. Jeśli zapytanie nie ma LIMIT, framework doda go automatycznie.', [
        ['name' => '$sql', 'type' => 'string', 'description' => 'Zapytanie SQL.'],
        ['name' => '$params', 'type' => 'array', 'description' => 'Parametry zapytania.'],
    ], 'Jeden rekord albo null.', [
        <<<'PHP'
$person = DB_GET('SELECT * FROM persons WHERE id = ?', [$id]);
PHP
    ], 'php');

    docsFunctionCard('Funkcja PHP', 'DB_EXECUTE', 'DB_EXECUTE($sql, $params = []): int', 'Wykonuje zapytanie modyfikujące dane, np. INSERT, UPDATE albo DELETE.', [
        ['name' => '$sql', 'type' => 'string', 'description' => 'Zapytanie SQL.'],
        ['name' => '$params', 'type' => 'array', 'description' => 'Parametry zapytania.'],
    ], 'Liczbę zmienionych wierszy.', [
        <<<'PHP'
DB_EXECUTE('DELETE FROM persons WHERE id = ?', [$id]);
PHP
    ], 'php');

    docsFunctionCard('Funkcja PHP', 'DB_LAST_ID', 'DB_LAST_ID(): string', 'Zwraca ostatni identyfikator wygenerowany po INSERT.', [], 'Ostatni identyfikator jako string.', [
        <<<'PHP'
$id = DB_LAST_ID();
PHP
    ], 'php');

    docsFunctionCard('Funkcja PHP', 'DB_TABLE', 'DB_TABLE($name): array', 'Pobiera wszystkie rekordy z jednej tabeli. To prosty helper do niewielkich tabel konfiguracyjnych i przykładów.', [
        ['name' => '$name', 'type' => 'string', 'description' => 'Nazwa tabeli.'],
    ], 'Tablicę rekordów.', [
        <<<'PHP'
$rates = DB_TABLE('rates');
PHP
    ], 'php');

    docsFunctionCard('Funkcja PHP', 'DB_SELECT', 'DB_SELECT($table, $fields = [], $where = [], $end = \'\'): array', 'Buduje prosty SELECT na podstawie nazwy tabeli, listy pól i warunków. Przydaje się do szybkich odczytów bez ręcznego składania całego SQL.', [
        ['name' => '$table', 'type' => 'string', 'description' => 'Nazwa tabeli.'],
        ['name' => '$fields', 'type' => 'array', 'description' => 'Lista pól do pobrania.'],
        ['name' => '$where', 'type' => 'array', 'description' => 'Proste warunki WHERE.'],
        ['name' => '$end', 'type' => 'string', 'description' => 'Opcjonalny końcowy fragment zapytania, np. ORDER BY.'],
    ], 'Tablicę rekordów.', [
        <<<'PHP'
$persons = DB_SELECT('persons', ['id', 'name', 'email'], [], 'ORDER BY `id` DESC');
PHP
    ], 'php');

    docsFunctionCard('Funkcja PHP', 'DB_INSERT', 'DB_INSERT($table, $data): string', 'Wykonuje INSERT na podstawie tablicy danych i zwraca nowy identyfikator.', [
        ['name' => '$table', 'type' => 'string', 'description' => 'Nazwa tabeli.'],
        ['name' => '$data', 'type' => 'array', 'description' => 'Tablica danych do zapisu.'],
    ], 'Identyfikator nowego rekordu.', [
        <<<'PHP'
$id = DB_INSERT('persons', [
  'name' => 'Jan Kowalski',
  'email' => 'jan@example.com'
]);
PHP
    ], 'php');

    docsFunctionCard('Funkcja PHP', 'DB_UPDATE', 'DB_UPDATE($table, $data, $where = []): int', 'Wykonuje UPDATE na podstawie tablicy danych i warunków WHERE.', [
        ['name' => '$table', 'type' => 'string', 'description' => 'Nazwa tabeli.'],
        ['name' => '$data', 'type' => 'array', 'description' => 'Dane do zmiany.'],
        ['name' => '$where', 'type' => 'array', 'description' => 'Warunki WHERE.'],
    ], 'Liczbę zmienionych rekordów.', [
        <<<'PHP'
DB_UPDATE('persons', [
  'name' => 'Jan Kowalski',
  'email' => 'jan@example.com'
], [
  'id' => 15
]);
PHP
    ], 'php');
    ?>
  </div>

  <div class="doc-subtitle"><i class="bi bi-journal-text me-2"></i>Logi i stan synchronizacji</div>
  <?php
  docsInfoCards([
      [
          'title' => 'datas/logs/php.log',
          'text' => 'Zapisuje błędy PHP. Logi są agregowane, więc identyczny błąd nie tworzy za każdym razem nowego wpisu, tylko aktualizuje licznik oraz datę pierwszego i ostatniego wystąpienia.'
      ],
      [
          'title' => 'datas/logs/sql.log',
          'text' => 'Zapisuje błędy SQL, w tym błędy zwykłych zapytań i błędy synchronizacji plików z app/db. Historia działa także przy debug = true, jeśli save_errors pozostaje włączone.'
      ],
      [
          'title' => 'datas/dbScheme/state.log',
          'text' => 'Przechowuje stan wykonania plików z app/db. Framework porównuje zapisany hash z aktualną zawartością pliku i decyduje, czy wymagana jest synchronizacja.'
      ],
  ]);
  ?>
</section>

<section id="layouts" class="doc-section" data-doc-title="Layouty" data-doc-keywords="layouts app layouts template content pageStart body docs default blank example-view">
  <div class="doc-section-header">
    <div class="doc-section-title-strong">Layouty</div>
    <p>Layout odpowiada za układ całego body strony. Dzięki niemu możesz używać różnych układów dla dokumentacji, przykładów i zwykłych widoków, bez kopiowania wspólnych elementów w każdym pliku.</p>
  </div>

  <?php
  docsHero(
      'Wspólny układ dla wielu stron',
      'Layout jest zwykłym plikiem PHP z folderu app/layouts. Otrzymuje zawartość strony w zmiennej content i może korzystać z danych przekazanych przez pageStart. To dobre miejsce na menu, sidebary, wrappery i wspólne sekcje dla większej grupy widoków.',
      <<<'PHP'
<?php
pageStart('Dokumentacja', 'docs', [
  'activeMenu' => 'docs',
  'sidebarTitle' => 'CookedFramework',
]);
?>
PHP,
      'php',
      ['app/layouts', 'pageStart', 'templateData']
  );
  ?>

  <?php
  docsInfoCards([
      [
          'title' => 'default.php',
          'text' => 'Standardowy układ strony. Dobrze sprawdza się dla zwykłych widoków aplikacji.'
      ],
      [
          'title' => 'docs.php',
          'text' => 'Układ dokumentacji z bocznym panelem i wyszukiwaniem sekcji.'
      ],
      [
          'title' => 'example-view.php',
          'text' => 'Układ do prezentacji przykładu i podglądu widoku obok siebie.'
      ],
      [
          'title' => 'blank.php',
          'text' => 'Minimalny układ bez dodatkowej struktury, przydatny dla prostych ekranów i specjalnych odpowiedzi.'
      ],
  ]);
  ?>
</section>

<section id="components" class="doc-section" data-doc-title="Componenty" data-doc-keywords="component app components menu sidebar php współdzielone fragmenty">
  <div class="doc-section-header">
    <div class="doc-section-title-strong">Componenty</div>
    <p>Componenty służą do współdzielonych fragmentów HTML po stronie PHP. Dzięki nim możesz utrzymać wspólne elementy interfejsu w jednym miejscu i używać ich na wielu stronach bez duplikowania kodu.</p>
  </div>

  <?php
  docsHero(
      'Powtarzalne fragmenty bez kopiowania HTML',
      'Component jest zwykłym plikiem PHP z folderu app/components. W odróżnieniu od bindingu nie służy do dynamicznego renderowania danych po stronie JavaScript, tylko do współdzielonej struktury widoku po stronie serwera.',
      <<<'PHP'
<?php
component('menu', [
  'items' => fwConfig('menu_items', []),
  'active' => 'docs',
]);
?>
PHP,
      'php',
      ['component', 'app/components', 'menu', 'sidebar']
  );
  ?>

  <div class="doc-grid">
    <?php
    docsFunctionCard('Funkcja PHP', 'component', 'component($name, $data = []): void', 'Renderuje plik componentu z folderu app/components i przekazuje mu dane pomocnicze.', [
        ['name' => '$name', 'type' => 'string', 'description' => 'Nazwa componentu bez rozszerzenia.'],
        ['name' => '$data', 'type' => 'array', 'description' => 'Dane przekazywane do componentu.'],
    ], 'Nie zwraca wartości.', [
        <<<'PHP'
<?php
component('docs-sidebar', [
  'title' => 'CookedFramework',
  'groups' => $docsCategoryGroups,
]);
?>
PHP
    ], 'php', [
        'Do renderowania prostych list danych preferuj binding. Component jest najlepszy dla współdzielonego HTML, nie dla zastępowania renderera danych.'
    ]);
    ?>
  </div>
</section>

<section id="animations" class="doc-section" data-doc-title="Animacje" data-doc-keywords="animations animation children-animation Animate play back reset trigger delay easing view click hover">
  <div class="doc-section-header">
    <div class="doc-section-title-strong">Animacje</div>
    <p>System animacji pozwala sterować wejściem elementów i dzieci głównie przez atrybuty HTML. Dzięki temu animacja pozostaje blisko widoku i nie wymaga każdorazowo osobnego kodu JavaScript dla prostych efektów wejścia i przejścia.</p>
  </div>

  <?php
  docsHero(
      'Atrybuty w HTML, sterowanie w JS tylko tam, gdzie trzeba',
      'Animacje są definiowane głównie przez atrybuty elementu. To wygodne przy sekcjach strony, kartach, listach i elementach pojawiających się po wejściu w viewport. Jeśli potrzebujesz sterowania programowego, możesz użyć metod Animate.play, Animate.back i Animate.reset.',
      <<<'HTML'
<div animation="pop,fade-in" animation-trigger="view" animation-time="500,300">
  <div class="card p-4">Nowa sekcja</div>
</div>
HTML,
      'html',
      ['animation', 'children-animation', 'animation-trigger', 'Animate.play']
  );
  ?>

  <div class="doc-grid">
    <?php
    docsFunctionCard('HTML', 'animation', 'animation="preset"', 'Ustawia animację elementu. Atrybut może przyjmować jeden albo kilka presetów rozdzielonych przecinkami.', [
        ['name' => 'preset', 'type' => 'string', 'description' => 'Nazwa presetu albo lista presetów.'],
    ], 'Nie zwraca wartości.', [
        <<<'HTML'
<div animation="pop,fade-in">Treść</div>
HTML
    ], 'html');

    docsFunctionCard('HTML', 'children-animation', 'children-animation="preset"', 'Ustawia animację dla dzieci elementu. Dobrze sprawdza się przy listach kart, sekcjach i grupach przycisków.', [
        ['name' => 'preset', 'type' => 'string', 'description' => 'Nazwa presetu dla dzieci.'],
    ], 'Nie zwraca wartości.', [
        <<<'HTML'
<div children-animation="fade-in" children-animation-delay="80">
  <div>Karta 1</div>
  <div>Karta 2</div>
</div>
HTML
    ], 'html', [
        'Dzieci z własnym animation albo children-animation nie powinny być nadpisywane przez rodzica.'
    ]);

    docsFunctionCard('HTML', 'animation-trigger / animation-time / animation-delay / animation-back / animation-once / animation-margin / animation-easing', 'animation-trigger="..." itd.', 'Zestaw atrybutów sterujących momentem startu, czasem, opóźnieniem, cofaniem i easingiem animacji.', [], 'Nie zwraca wartości.', [
        <<<'HTML'
<div
  animation="zoom-in"
  animation-trigger="view"
  animation-time="500"
  animation-delay="120"
  animation-once="true"
  animation-margin="80"
  animation-easing="ease-out">
  Treść
</div>
HTML
    ], 'html');

    docsFunctionCard('Funkcja JS', 'Animate.play / Animate.back / Animate.reset', 'Animate.play(target) / Animate.back(target) / Animate.reset(target)', 'Steruje animacją z poziomu JavaScript wtedy, gdy potrzebujesz reakcji na zdarzenie lub własną logikę strony.', [], 'Nie zwraca wartości.', [
        <<<'JAVASCRIPT'
click('showSummary', () => {
  Animate.play('#summaryCard');
});
JAVASCRIPT
    ], 'javascript');
    ?>
  </div>
</section>

<section id="ai-docs" class="doc-section" data-doc-title="Dokumentacja dla AI" data-doc-keywords="ai dokumentacja dla ai funkcje opis lista chat prompt helpery">
  <div class="doc-section-header">
    <div class="doc-section-title-strong">Dokumentacja dla AI</div>
    <p>Ta sekcja jest przygotowana jako skrócony blok do wklejenia do chata. Zawiera listę funkcji i mechanizmów frameworka wraz z krótkim opisem ich roli, bez sygnatur i tabel parametrów.</p>
  </div>

  <?php
  docsHero(
      'Krótki opis funkcji do użycia w rozmowie z modelem',
      'Ten blok ma pomóc modelowi szybko zorientować się, jakie mechanizmy są dostępne i do czego służą. Szczegóły działania, parametry i przykłady są opisane w pozostałych sekcjach dokumentacji.',
      $aiFunctionsText,
      'plaintext',
      ['AI', 'skrót funkcji', 'opis mechanizmów', 'prompt']
  );
  ?>
</section>

<section id="ai" class="doc-section" data-doc-title="AI" data-doc-keywords="ai framework cookedframework php javascript html css bootstrap binding defaultBinding innerBinding template pageStart pageEnd layout component modal tabs send get getRaw db_select db_insert db_update routing docs examples api data page-data public assets public img app config animate drag tabs modals field button source zip onapi datas logs dbScheme route setText hide getValue hasItems edit keyDown keyUp">
  <div class="doc-section-header">
    <div class="doc-section-title-strong">AI</div>
    <p>Ten blok zostaje utrzymany jako gotowy zestaw zasad do wykorzystania przy generowaniu kodu przez model AI.</p>
  </div>

  <div class="doc-intro">
    <div class="doc-intro-kicker"><i class="bi bi-robot"></i>Wprowadzenie</div>
    <h2 class="doc-intro-title">Jak korzystać z kodu frameworka z zipa</h2>
    <p class="doc-intro-text">Ten blok ma nauczyć model, jak efektywnie korzystać z plików źródłowych frameworka i jak generować jedną kompletną stronę w jednym promptcie.</p>


    <div class="doc-intro-example-title"><i class="bi bi-journal-code me-2"></i>Zasady dla modelu</div>
    <?php docsCode($aiPromptOldB, 'plaintext'); ?>
  </div>
</section>

<section id="workflow" class="doc-section" data-doc-title="workflow" data-doc-keywords="workflow pageStart pageEnd component layout binding api db modal animation route datas logs">
  <div class="doc-section-header">
    <div class="doc-section-title-strong">workflow</div>
    <p>Najczęstszy sposób pracy z frameworkiem jest prosty: od strony i HTML, przez binding i requesty, aż do zapisu danych i logiki pomocniczej. Dzięki temu można budować funkcjonalności krok po kroku bez nadmiarowej architektury.</p>
  </div>

  <?php
  docsHero(
      'Typowy sposób pracy',
      'Najczęściej tworzysz stronę, dodajesz HTML, wybierasz binding albo helpery API, a dopiero na końcu rozszerzasz widok o modale, tabs, animacje czy dodatkowe komponenty. Taki porządek pracy ułatwia utrzymanie spójności całego projektu.',
      null,
      'plaintext',
      ['pageStart', 'binding', 'API', 'DB', 'modale', 'animacje', 'datas']
  );
  ?>

  <div class="doc-note-box">
    <ol class="mb-0 ps-3">
      <li>Tworzysz plik strony w <code class="doc-inline-code">app/pages</code>.</li>
      <li>Rozpoczynasz widok przez <code class="doc-inline-code">pageStart</code> i wybierasz layout, jeśli jest potrzebny.</li>
      <li>Piszesz zwykły HTML i PHP, a dane do widoku przekazujesz przez <code class="doc-inline-code">pageEnd</code> albo przez API.</li>
      <li>Do renderowania danych wybierasz binding zamiast ręcznego składania list przez JavaScript.</li>
      <li>Requesty wysyłasz helperami <code class="doc-inline-code">get</code>, <code class="doc-inline-code">getRaw</code> i <code class="doc-inline-code">send</code>.</li>
      <li>Do pracy z bazą używasz helperów <code class="doc-inline-code">DB_*</code>.</li>
      <li>Definicje tabel trzymasz w <code class="doc-inline-code">app/db</code>, a stan synchronizacji i logi w <code class="doc-inline-code">datas</code>.</li>
      <li>Modale, tabs i animacje dodajesz tam, gdzie realnie upraszczają obsługę widoku.</li>
    </ol>
  </div>
</section>

<script>
(function () {
  function escapeHtml(text) {
    return String(text)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;");
  }

  function highlightCode() {
    const blocks = document.querySelectorAll('.doc-code code');

    blocks.forEach(function (block) {
      let html = escapeHtml(block.textContent);

      html = html.replace(/(\/\/.*$)/gm, '<span class="hl-comment">$1<\/span>');
      html = html.replace(/(#.*$)/gm, '<span class="hl-comment">$1<\/span>');
      html = html.replace(/\b(function|return|new|const|let|var|if|else|foreach|as|echo|class|public|private|protected|static|try|catch|throw|await|async)\b/g, '<span class="hl-keyword">$1<\/span>');
      html = html.replace(/\b([0-9]+)\b/g, '<span class="hl-number">$1<\/span>');
      html = html.replace(/\b([a-zA-Z_][a-zA-Z0-9_]*)\s*(?=\()/g, '<span class="hl-function">$1<\/span>');
      html = html.replace(/(\$[a-zA-Z_][a-zA-Z0-9_]*)/g, '<span class="hl-variable">$1<\/span>');

      block.innerHTML = html;
    });
  }

  const searchInput = document.getElementById('docsSearch');
  const emptyBox = document.getElementById('docsSearchEmpty');
  const sections = Array.from(document.querySelectorAll('.doc-section'));
  const links = Array.from(document.querySelectorAll('[data-doc-link]'));
  const groups = Array.from(document.querySelectorAll('[data-doc-group]'));

  groups.forEach(function (group) {
    const button = group.querySelector('[data-doc-group-button]');
    const body = group.querySelector('[data-doc-group-body]');

    if (button && body) {
      const title = button.textContent.trim();
      const titleEl = document.createElement('div');
      titleEl.className = 'docs-nav-group-title';
      titleEl.textContent = title;
      group.insertBefore(titleEl, body);
      body.style.display = '';
      button.style.display = 'none';
    }
  });

  function normalize(text) {
    return String(text || '')
      .toLowerCase()
      .normalize('NFD')
      .replace(/[\u0300-\u036f]/g, '');
  }

  function getSectionById(id) {
    return sections.find(function (section) {
      return section.id === id;
    }) || null;
  }

  function showOnlySection(id) {
    sections.forEach(function (section) {
      const active = section.id === id;
      section.classList.toggle('is-active', active);
    });
  }

  function activateLink(id) {
    links.forEach(function (link) {
      const active = link.dataset.docTarget === id;
      link.classList.toggle('active', active);
    });

    if (id) {
      showOnlySection(id);
    }
  }

  links.forEach(function (link) {
    link.addEventListener('click', function () {
      activateLink(link.dataset.docTarget || '');
    });
  });

  function filterDocs() {
    const query = normalize(searchInput ? searchInput.value : '');

    links.forEach(function (link) {
      const section = getSectionById(link.dataset.docTarget || '');
      const haystack = section
        ? normalize((section.dataset.docTitle || '') + ' ' + (section.dataset.docKeywords || '') + ' ' + section.textContent)
        : '';

      const visible = query === '' || haystack.includes(query);
      link.style.display = visible ? '' : 'none';
    });

    const visibleLinks = links.filter(function (link) {
      return link.style.display !== 'none';
    });

    groups.forEach(function (group) {
      const visibleInGroup = Array.from(group.querySelectorAll('[data-doc-link]')).some(function (link) {
        return link.style.display !== 'none';
      });

      group.style.display = visibleInGroup ? '' : 'none';
    });

    if (emptyBox) {
      emptyBox.style.display = visibleLinks.length === 0 ? '' : 'none';
    }

    if (visibleLinks.length === 0) {
      sections.forEach(function (section) {
        section.classList.remove('is-active');
      });
      return;
    }

    if (query !== '') {
      activateLink(visibleLinks[0].dataset.docTarget || '');
      return;
    }

    const activeLink = document.querySelector('.docs-nav-link.active') || visibleLinks[0];
    if (activeLink) {
      activateLink(activeLink.dataset.docTarget || '');
    }
  }

  if (searchInput) {
    searchInput.addEventListener('input', filterDocs);
  }

  const startId = location.hash ? location.hash.replace('#', '') : (links[0] ? links[0].dataset.docTarget || '' : '');

  highlightCode();
  activateLink(startId);
  filterDocs();
})();
</script>

<?php pageEnd(); ?>