<?php
$api = $_GET['api'] ?? '';

if ($api === 'list') {
    output([
        'persons' => DB_SELECT('persons', ['id', 'name', 'email'], [], 'ORDER BY `id` DESC')
    ]);
}

if ($api === 'create') {
    $data = input();

    $id = DB_INSERT('persons', [
        'name' => $data['name'] ?? '',
        'email' => $data['email'] ?? '',
    ]);

    output(['id' => $id]);
}

if ($api === 'update') {
    $data = input();

    DB_UPDATE('persons', [
        'name' => $data['name'] ?? '',
        'email' => $data['email'] ?? '',
    ], [
        'id' => $data['id'] ?? 0
    ]);

    output(['ok' => true]);
}

if ($api === 'delete') {
    $data = input();
    DB_EXECUTE('DELETE FROM `persons` WHERE `id` = ?', [$data['id'] ?? 0]);

    output(['ok' => true]);
}

pageStart('Przykład: CRUD persons');
?>

<div class="d-flex align-items-center justify-content-between mb-3">
  <h1 class="h3 m-0">Lista osób z edycją przez modal</h1>
  <button id="btnAddPerson" class="btn btn-primary">Dodaj osobę</button>
</div>

<p class="text-muted">
  Lista umożliwia dodawanie, edycję i usuwanie rekordów bez przeładowania strony. Formularz edycji otwiera się od razu z uzupełnionymi polami.
</p>

<div class="card">
  <div class="card-body">
    <div binding="persons">
      <div template class="d-flex justify-content-between align-items-center border-bottom py-2">
        <div>
          <div class="fw-semibold">{{name}}</div>
          <div class="text-muted small">{{email}}</div>
        </div>

        <div class="d-flex gap-2">
          <button
            class="btn btn-sm btn-outline-secondary"
            data-edit-person-id="{{id}}"
            data-name="{{name}}"
            data-email="{{email}}">
            Edytuj
          </button>

          <button class="btn btn-sm btn-outline-danger" data-delete-person-id="{{id}}" data-name="{{name}}">Usuń</button>
        </div>
      </div>
    </div>
  </div>
</div>

<script>
async function loadPersons()
{
    const data = await get("api::list");
    Binding.set("persons", data.persons || []);
}

function createPersonForm(title, values = {})
{
    const nameField = Field.text(
        "name",
        "Imię i nazwisko",
        "np. Jan Kowalski",
        [true, "To pole nie może być puste"]
    );

    nameField.value = values.name ?? "";

    const emailField = Field.email(
        "email",
        "E-mail",
        "np. jan@example.com",
        ["^[^\\s@]+@[^\\s@]+\\.[^\\s@]+$", "Podaj poprawny adres e-mail"]
    );

    emailField.value = values.email ?? "";

    return new ModalForm(
        title,
        [nameField, emailField],
        [
            Button.close("Anuluj", false, "btn-secondary"),
            Button.submit("Zapisz", "btn-primary")
        ]
    );
}

click("btnAddPerson", async () =>
{
    const data = await createPersonForm("Nowa osoba").show();

    if (!data) {
        return;
    }

    await send("api::create", data);
    await loadPersons();
});

clickData("edit-person-id", async (id, button) =>
{
    const data = await createPersonForm("Edytuj osobę", {
        name: button.dataset.name || "",
        email: button.dataset.email || ""
    }).show();

    if (!data) {
        return;
    }

    data.id = id;

    await send("api::update", data);
    await loadPersons();
});

clickData("delete-person-id", async (id, button) =>
{
    const ok = await new ModalConfirm(
        "Usuń osobę",
        "Czy na pewno usunąć: " + (button.dataset.name || "") + "?"
    ).show();

    if (!ok) {
        return;
    }

    await send("api::delete", { id: id });
    await loadPersons();
});

loadPersons();
</script>

<?php pageEnd(); ?>
