<?php
pageStart('Przykłady frameworka');
?>

<h1 class="h3 mb-3">Przykłady frameworka</h1>

<p class="text-muted">
  Zestaw gotowych scenariuszy pokazujących, jak łączyć binding, API, modale i dane z bazy w bardziej kompletnych widokach.
</p>

<div class="card">
  <div class="card-body">
    <div defaultBinding="examples">
      <div template class="border rounded p-3 mb-2">
        <a class="fw-bold link" href="{{url}}">{{title}}</a>
        <div class="text-muted small">{{description}}</div>
      </div>
    </div>
  </div>
</div>

<?php pageEnd([
    'examples' => [
        [
            'title' => 'Dashboard z danych PHP',
            'description' => 'Karty i sekcje zasilane danymi przekazanymi bezpośrednio z PHP.',
            'url' => fwUrl('examples/dashboard'),
        ],
        [
            'title' => 'Lista z wyszukiwaniem przez API',
            'description' => 'Filtrowanie wyników na bieżąco i aktualizacja bindingu bez przeładowania strony.',
            'url' => fwUrl('examples/search-list'),
        ],
        [
            'title' => 'Potwierdzenia i komunikaty',
            'description' => 'Obsługa decyzji użytkownika z wykorzystaniem ModalInfo i ModalConfirm.',
            'url' => fwUrl('examples/modal-form'),
        ],
        [
            'title' => 'Zagnieżdżone zamówienia',
            'description' => 'Listy wewnętrzne renderowane przez defaultBinding i innerBinding.',
            'url' => fwUrl('examples/nested-orders'),
        ],
        [
            'title' => 'Lista osób z edycją',
            'description' => 'Widok danych z bazy z dodawaniem, edycją i usuwaniem rekordów przez API.',
            'url' => fwUrl('examples/persons-crud'),
        ],
    ]
]); ?>
