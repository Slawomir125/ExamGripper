<?php
pageStart('Przykład: potwierdzenia i komunikaty');
?>

<div class="d-flex align-items-center justify-content-between mb-3">
  <h1 class="h3 m-0">Potwierdzenia i komunikaty</h1>
  <button id="btnResetStatuses" class="btn btn-outline-secondary">Przywróć stan początkowy</button>
</div>

<p class="text-muted">
  Ten widok pokazuje, jak wykorzystać modale do potwierdzania akcji i prezentowania krótkich komunikatów zwrotnych bez opuszczania bieżącej strony.
</p>

<div class="card">
  <div class="card-body">
    <div binding="tasks">
      <div template class="d-flex justify-content-between align-items-center border-bottom py-2">
        <div>
          <div class="fw-semibold">{{title}}</div>
          <div class="text-muted small">Status: {{status}}</div>
        </div>

        <div class="d-flex gap-2">
          <button class="btn btn-sm btn-outline-primary" data-details-id="{{id}}" data-title="{{title}}" data-status="{{status}}">Szczegóły</button>
          <button class="btn btn-sm btn-success" data-finish-id="{{id}}" data-title="{{title}}">Zakończ</button>
        </div>
      </div>
    </div>
  </div>
</div>

<script>
const initialTasks = [
    { id: 1, title: "Przygotować rozliczenie magazynu", status: "W trakcie" },
    { id: 2, title: "Zweryfikować odczyty w hali 2", status: "Do sprawdzenia" },
    { id: 3, title: "Wysłać podsumowanie dla najemcy", status: "Gotowe do wysyłki" }
];

let tasks = [];

function renderTasks()
{
    Binding.set("tasks", tasks);
}

function resetTasks()
{
    tasks = initialTasks.map((item) => ({ ...item }));
    renderTasks();
}

clickData("details-id", async (id, button) =>
{
    await new ModalInfo(
        button.dataset.title || "Szczegóły",
        "Aktualny status: " + (button.dataset.status || "")
    ).show();
});

clickData("finish-id", async (id, button) =>
{
    const ok = await new ModalConfirm(
        "Zamknij zadanie",
        "Czy oznaczyć jako zakończone: " + (button.dataset.title || "") + "?"
    ).show();

    if (!ok) {
        return;
    }

    tasks = tasks.map((item) =>
    {
        if (String(item.id) !== String(id)) {
            return item;
        }

        return {
            ...item,
            status: "Zakończone"
        };
    });

    renderTasks();

    await new ModalInfo(
        "Status został zaktualizowany",
        "Pozycja została oznaczona jako zakończona."
    ).show();
});

click("btnResetStatuses", () =>
{
    resetTasks();
});

resetTasks();
</script>

<?php pageEnd(); ?>
