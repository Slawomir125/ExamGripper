<?php
pageStart('Przykład: zagnieżdżone zamówienia');
?>

<h1 class="h3 mb-3">Zagnieżdżone zamówienia</h1>

<p class="text-muted">
  To układ przydatny w widokach, w których jedna sekcja zawiera własną listę pozycji, na przykład zamówienia z produktami albo zestawienia z wieloma kategoriami.
</p>

<div defaultBinding="orders">
  <div template class="card mb-3">
    <div class="card-body">
      <div class="d-flex justify-content-between align-items-center mb-3">
        <div>
          <div class="fw-bold">Zamówienie {{number}}</div>
          <div class="text-muted small">Klient: {{customer}}</div>
        </div>
        <div class="badge text-bg-secondary">{{status}}</div>
      </div>

      <ul class="list-group" innerBinding="{{items}}">
        <li template class="list-group-item">
          <div class="fw-semibold">{{name}}</div>
          <div class="small text-muted">Zamówienie: {{*.number}} | Ilość: {{qty}}</div>
        </li>
      </ul>
    </div>
  </div>
</div>

<?php pageEnd([
    'orders' => [
        [
            'number' => 'ZAM-001',
            'customer' => 'ABI-POL',
            'status' => 'Nowe',
            'items' => [
                ['name' => 'Płyta piaskowca 80x40x4', 'qty' => 12],
                ['name' => 'Parapet 150x35x4', 'qty' => 4],
            ]
        ],
        [
            'number' => 'ZAM-002',
            'customer' => 'Magazyn Wrocław',
            'status' => 'W realizacji',
            'items' => [
                ['name' => 'Licznik wody', 'qty' => 2],
                ['name' => 'Czujnik temperatury', 'qty' => 5],
                ['name' => 'Przewód instalacyjny', 'qty' => 30],
            ]
        ]
    ]
]); ?>
