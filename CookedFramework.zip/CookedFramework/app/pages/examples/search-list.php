<?php
function exampleProducts(): array
{
    return [
        ['name' => 'Prąd Wrocław', 'unit' => 'kWh'],
        ['name' => 'Woda zimna', 'unit' => 'm3'],
        ['name' => 'Woda ciepła', 'unit' => 'm3'],
        ['name' => 'Gaz', 'unit' => 'm3'],
        ['name' => 'Internet', 'unit' => 'miesiąc'],
        ['name' => 'Ogrzewanie', 'unit' => 'GJ'],
        ['name' => 'Ścieki', 'unit' => 'm3'],
    ];
}

if (($_GET['api'] ?? '') === 'list') {
    $q = trim($_GET['q'] ?? '');

    $items = array_values(array_filter(exampleProducts(), function ($item) use ($q) {
        if ($q === '') {
            return true;
        }

        return stripos($item['name'], $q) !== false
            || stripos($item['unit'], $q) !== false;
    }));

    output(['items' => $items]);
}

pageStart('Przykład: lista z wyszukiwaniem');
?>

<div class="d-flex align-items-center justify-content-between mb-3">
  <h1 class="h3 m-0">Lista z wyszukiwaniem przez API</h1>
</div>

<p class="text-muted">
  Wyniki odświeżają się podczas wpisywania tekstu. Lista korzysta ze zwykłego <code>binding</code>, dlatego dane są ustawiane ręcznie po odpowiedzi z API.
</p>

<div class="row g-2 mb-3">
  <div class="col-md-7">
    <input id="searchText" type="text" class="form-control" placeholder="Wpisz nazwę lub jednostkę">
  </div>
  <div class="col-md-2">
    <button id="btnClear" class="btn btn-outline-secondary w-100">Wyczyść</button>
  </div>
</div>

<div class="card">
  <div class="card-body">
    <div binding="items">
      <div template class="border-bottom py-2">
        <div class="fw-semibold">{{name}}</div>
        <div class="text-muted small">Jednostka: {{unit}}</div>
      </div>
    </div>
  </div>
</div>

<script>
async function loadItems(query = "")
{
    const data = await get("api::list", { q: query });
    Binding.set("items", data.items || []);
}

edit("searchText", async () =>
{
    await loadItems(getValue("searchText").trim());
});

click("btnClear", async () =>
{
    const searchInput = document.getElementById("searchText");
    searchInput.value = "";
    await loadItems("");
});

loadItems();
</script>

<?php pageEnd(); ?>
