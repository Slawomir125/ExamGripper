<?php
pageStart('Przykład: dashboard');
?>

<h1 class="h3 mb-4">Dashboard z danych PHP</h1>

<p class="text-muted">
  Dane przekazane do <code>pageEnd()</code> mogą od razu zasilać karty, listy i sekcje podsumowujące bez dodatkowego pobierania po stronie przeglądarki.
</p>

<div class="row g-3 mb-4" defaultBinding="stats">
  <div template class="col-md-4">
    <div class="card h-100">
      <div class="card-body">
        <div class="text-muted small">{{label}}</div>
        <div class="display-6 fw-bold">{{value}}</div>
        <div class="small text-success">{{note}}</div>
      </div>
    </div>
  </div>
</div>

<div class="card">
  <div class="card-body">
    <h2 class="h5 mb-4">Ostatnie aktywności</h2>

    <div defaultBinding="activities">
      <div template class="border-bottom py-2">
        <div class="fw-semibold">{{title}}</div>
        <div class="text-muted small">{{date}}</div>
      </div>
    </div>
  </div>
</div>

<?php pageEnd([
    'stats' => [
        ['label' => 'Najemcy', 'value' => 24, 'note' => '+2 w tym tygodniu'],
        ['label' => 'Liczniki', 'value' => 87, 'note' => '3 archiwalne'],
        ['label' => 'Odczyty dziś', 'value' => 16, 'note' => 'Na bieżąco'],
    ],
    'activities' => [
        ['title' => 'Dodano nowego najemcę', 'date' => '2026-03-14 09:20'],
        ['title' => 'Zaktualizowano odczyt w hali 1', 'date' => '2026-03-14 10:05'],
        ['title' => 'Wysłano podsumowanie mediów', 'date' => '2026-03-14 11:40'],
    ]
]); ?>
