<?php
$title = $title ?? 'Dokumentacja';
$groups = $groups ?? [];
?>

<div class="docs-sidebar-stick">
  <div class="docs-sidebar border rounded-4 bg-white shadow-sm">
    <div class="p-3 border-bottom">

      <input
        id="docsSearch"
        type="search"
        class="form-control"
        placeholder="Szukaj w dokumentacji"
        autocomplete="off"
      >

      <div class="small text-muted mt-2">
        Szukaj po nazwach metod, parametrach, słowach kluczowych i treści.
      </div>

      <div id="docsSearchEmpty" class="docs-search-empty small text-muted mt-2">
        Brak wyników.
      </div>
    </div>

    <div class="p-3">
      <?php foreach ($groups as $groupIndex => $group): ?>
        <?php
          $groupTitle = $group['title'] ?? '';
          $items = $group['items'] ?? [];
          $isOpen = $groupIndex === 0;
        ?>

        <div class="docs-nav-group" data-doc-group>
          <button
            type="button"
            class="docs-nav-group-button"
            data-doc-group-button
            aria-expanded="<?= $isOpen ? 'true' : 'false' ?>"
          >
            <span><?= htmlspecialchars($groupTitle, ENT_QUOTES, 'UTF-8') ?></span>
            <i class="bi bi-chevron-down"></i>
          </button>

          <div
            class="docs-nav-group-body"
            data-doc-group-body
            style="<?= $isOpen ? '' : 'display:none;' ?>"
          >
            <nav class="nav nav-pills flex-column">
              <?php foreach ($items as $item): ?>
                <?php
                  $id = $item['id'] ?? '';
                  $label = $item['label'] ?? $id;
                ?>

                <a
                  href="#<?= htmlspecialchars($id, ENT_QUOTES, 'UTF-8') ?>"
                  class="docs-nav-link"
                  data-doc-link
                  data-doc-target="<?= htmlspecialchars($id, ENT_QUOTES, 'UTF-8') ?>"
                >
                  <?= htmlspecialchars($label, ENT_QUOTES, 'UTF-8') ?>
                </a>
              <?php endforeach; ?>
            </nav>
          </div>
        </div>
      <?php endforeach; ?>
    </div>
  </div>
</div>