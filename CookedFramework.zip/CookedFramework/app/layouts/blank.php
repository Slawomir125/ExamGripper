<div class="container py-5">
  <?= $content ?>
</div>