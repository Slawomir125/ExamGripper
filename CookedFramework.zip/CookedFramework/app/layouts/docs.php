<?php
$menuItems = $templateData['menuItems'] ?? fwConfig('menu_items', []);
$activeMenu = $templateData['activeMenu'] ?? fwCurrentPath();

$sidebarTitle = $templateData['sidebarTitle'] ?? 'Dokumentacja';
$sidebarGroups = $templateData['sidebarGroups'] ?? [];
?>

<?php component('menu', [
    'items' => $menuItems,
    'active' => $activeMenu
]); ?>

<div class="container-fluid docs-layout py-4 ">
  <div class="row g-4">
    <aside class="col-12 col-lg-4 col-xl-3">
      <?php component('docs-sidebar', [
          'title' => $sidebarTitle,
          'groups' => $sidebarGroups
      ]); ?>
    </aside>

    <main class="col-12 col-lg-8 col-xl-9 docs-content">
      <?= $content ?>
    </main>
  </div>
</div>
