<?php
$exampleTitle = $exampleTitle ?? ($title ?? 'Przykład');
$exampleDescription = $exampleDescription ?? '';
$exampleIcon = $exampleIcon ?? 'bi-code-slash';

$currentPath = fwCurrentPath();
$pageFile = __DIR__ . '/../pages/' . $currentPath . '.php';
$pageCode = '';

if (is_file($pageFile)) {
    $pageCode = (string)file_get_contents($pageFile);
} else {
    $pageCode = '// Nie znaleziono pliku: ' . $currentPath . '.php';
}
?>

<style>

.example-layout-top {
  padding:0 1.5rem 
}

.example-layout-back {
  display: inline-flex;
  align-items: center;
  gap: .45rem;
  text-decoration: none;
  font-weight: 700;
}

.function-workspace-card {
  border: 0;
  border-radius: 1rem;
  overflow: hidden;
  box-shadow: 0 .5rem 1.5rem rgba(0, 0, 0, .06);
}

.function-workspace-row {
  --bs-gutter-x: 0;
  --bs-gutter-y: 0;
}

.function-pane + .function-pane {
  border-left: 1px solid rgba(0, 0, 0, .08);
}

.function-toolbar {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 1rem;
  padding: .85rem 1rem;
  background: var(--bs-light);
  border-bottom: 1px solid rgba(0, 0, 0, .08);
}

.function-toolbar-title {
  display: inline-flex;
  align-items: center;
  gap: .6rem;
  font-weight: 700;
}

.function-toolbar-title i {
  color: var(--bs-primary);
}

.function-code-box {
  background: #1e1e1e;
  color: #d4d4d4;
  min-height: 78vh;
  max-height: 78vh;
  overflow: auto;
}

.function-code-box pre {
  margin: 0;
  padding: 1rem 1.1rem 1.2rem;
  font-size: .8rem;
  line-height: 1.45;
  font-family: var(--bs-font-monospace);
  white-space: pre;
}

.function-code-box code {
  display: block;
}

.function-preview-box {
  background: #fff;
  min-height: 78vh;
  max-height: 78vh;
  overflow: auto;
}

.function-preview-card {
  border: 0;
  background: #fff;
  min-height: calc(78vh - 3.4rem);
}

.function-preview-card-inner {
  padding: 1.25rem;
}

@media (max-width: 1199.98px) {
  .function-pane + .function-pane {
    border-left: 0;
    border-top: 1px solid rgba(0, 0, 0, .08);
  }

  .function-code-box,
  .function-preview-box {
    min-height: 28rem;
    max-height: none;
  }

  .function-preview-card {
    min-height: 24rem;
  }
}
</style>

<div class="example-layout-shell">
  <div class="card function-workspace-card" children-animation="fade-up" animation-trigger="default" animation-time="0.5s" children-animation-delay="0.08s">
    <div class="row function-workspace-row align-items-stretch">
      <div class="col-12 col-xl-5 function-pane">
        <div class="function-toolbar">
          <div class="function-toolbar-title">
            <i class="bi bi-code-slash"></i>
            <span>Kod źródłowy</span>
            <a href="<?= htmlspecialchars(fwUrl('functions'), ENT_QUOTES, 'UTF-8') ?>" class="example-layout-back">
              <i class="bi bi-arrow-left"></i>
              Wróć do listy funkcji
            </a>
          </div>
          <div class="text-muted small"><?= htmlspecialchars(basename($pageFile), ENT_QUOTES, 'UTF-8') ?></div>
        </div>

        <div class="function-code-box">
          <pre><code class="function-source-code"><?= htmlspecialchars($pageCode, ENT_QUOTES, 'UTF-8') ?></code></pre>
        </div>
      </div>

      <div class="col-12 col-xl-7 function-pane">
        <div class="function-toolbar">
          <div class="function-toolbar-title">
            <i class="bi bi-window"></i>
            <span>Podgląd strony</span>
          </div>
          <div class="text-muted small">Aktualny widok</div>
        </div>

        <div class="function-preview-box">
          <div class="function-preview-card">
            <div class="function-preview-card-inner">
              <?= $content ?>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>